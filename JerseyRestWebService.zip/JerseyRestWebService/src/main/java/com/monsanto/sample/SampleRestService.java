package com.monsanto.sample;

import java.io.IOException;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.monsanto.common.StringConstants;
import com.monsanto.dao.AbstractDAOService;
import com.monsanto.dao.DAOFactory;
import com.monsanto.dao.RestDAO;
import com.monsanto.service.Json;

@Path("/sampleservice")
public class SampleRestService {

	RestDAO restDAO = new RestDAO();

	@GET
	@Path("/json")
	@Produces(MediaType.APPLICATION_JSON)
	public Json loadJsonDBData(@QueryParam("ClassName") String className, @QueryParam("Columns") String columns,
			@QueryParam("FilterBy") String filterBy) throws IOException {

		List<Object> dynamicDbObject = restDAO.loadDynamicObjectFromDB(className, checkNULL(columns),
				checkNULL(filterBy));

		Json json = new Json("JsonData", dynamicDbObject);

		return json;
	}

	@GET
	@Path("/jsons")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Json> loadListOfJsonDBData(@QueryParam("ClassName") String className) throws IOException {

		List<Json> dynamicDbObject = restDAO.loadListOfJsonDatas(className);

		return dynamicDbObject;
	}

	@GET
	@Path("/jsons1")
	@Produces(MediaType.APPLICATION_JSON)
	public Response loadListOfJsonDBData1(@QueryParam("ClassName") String className,
			@QueryParam("Columns") String columns, @QueryParam("FilterBy") String filterBy) throws IOException {

		AbstractDAOService daoFactory = DAOFactory.getFactory(StringConstants.PSQL_FACTORY_NAME);
		List<Json> dynamicDbObject = daoFactory.loadListOfJsonDatas(className);

		return Response.ok().entity(dynamicDbObject).header("Access-Control-Allow-Origin", "*").build();
	}

	@GET
	@Path("/json1")
	@Produces(MediaType.APPLICATION_JSON)
	public Response loadJsonDBData1(@QueryParam("ClassName") String className, @QueryParam("Columns") String columns,
			@QueryParam("FilterBy") String filterBy) throws IOException {

		List<Object> dynamicDbObject = restDAO.loadDynamicObjectFromDB(className, checkNULL(columns),
				checkNULL(filterBy));

		Json json = new Json("JsonData", dynamicDbObject);

		return Response.ok().entity(json).header("Access-Control-Allow-Origin", "*").build();
	}

	private String checkNULL(String params) {
		if (params == null) {
			params = "";
		}
		return params;
	}

}
