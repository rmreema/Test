package com.monsanto.sample;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;

import com.monsanto.common.StringConstants;

public class DatabaseCreation {


	public static void main(String[] args) throws SQLException {
		Connection connection = getDBConnection();
		Statement stmt = null;
		try {
			connection.setAutoCommit(false);
			stmt = connection.createStatement();
			
			/*stmt.executeUpdate("insert into usersTables values('finance','finance')");
			stmt.executeUpdate("insert into user_roles values('finance','finance')");
			
			stmt.executeUpdate("insert into usersTables values('Admin','Admin')");
			stmt.executeUpdate("insert into user_roles values('Admin','test')");*/
			
			/*stmt.execute(
					"DROP TABLE Widget");*/
			
			
			/*stmt.execute("create table Student(name varchar(60),email varchar(60),pass varchar(100))");*/
			/*stmt.execute("CREATE TABLE Widget(chartType varchar(50),xkeys varchar(50),ykeys varchar(50),title varchar(50),role varchar(50))"); */

			// String jsonStructure = JsonTestClass.convertJsonStructure();

			/*stmt.execute(
					"CREATE TABLE Pojo3(id varchar(100) primary key,name varchar(100), desc varchar(100), location varchar(100), address varchar(100))");*/
			
			/*stmt.execute(
					"CREATE TABLE Model(id varchar(100) primary key,name varchar(100), desc varchar(100), location varchar(100), address varchar(100))");*/
			
			/*stmt.execute(
					"CREATE TABLE SampleModel(x varchar(100) primary key,y varchar(100), z varchar(100))");*/
			/*stmt.execute(
					"create table usersTables(user_name varchar(15) not null primary key, user_pass varchar(15) not null)");
			stmt.execute(
					"create table user_roles (user_name varchar(15) not null, role_name varchar(15) not null, primary key (user_name, role_name))");*/
			
			/*stmt.executeUpdate("insert into usersTables values('test','test')");
			stmt.executeUpdate("insert into user_roles values('test','test')");*/
			
			/*stmt.executeUpdate("insert into usersTables values('arun','arun')");
			stmt.executeUpdate("insert into user_roles values('arun','arun')");*/
			
			/*stmt.execute(
					"CREATE TABLE SampleModel1(y varchar(100) primary key,a varchar(100), b varchar(100))");*/
			
			/*stmt.execute(
					"INSERT INTO Model(id ,name , desc , location , address ) VALUES('582066', 'Arun','Associate','CKC','Madurai')");*/
			
			/*stmt.execute(
					"INSERT INTO Pojo3(id ,name , desc , location , address ) VALUES('582066', 'Arun','Associate','CKC','Madurai')");
			stmt.execute(
					"INSERT INTO Pojo3(id ,name , desc , location , address ) VALUES('121212', 'arun1','Associate','CKC','chennai')");*/
			
			/*stmt.execute(
					"CREATE TABLE BarChart(y varchar(100) primary key,a varchar(100), b varchar(100))");
			
			stmt.execute(
					"INSERT INTO BarChart(y ,a, b ) VALUES('2006', '100','90')");
			stmt.execute(
					"INSERT INTO BarChart(y ,a, b ) VALUES('2007', '75','65')");
			stmt.execute(
					"INSERT INTO BarChart(y ,a, b ) VALUES('2008', '100','90')");
			stmt.execute(
					"INSERT INTO BarChart(y ,a, b ) VALUES('2009', '100','90')");*/
			
			
			//ResultSet rs = stmt.executeQuery("select * from Pojo3");

			String query1 = "SELECT u.user_name,u.user_pass FROM  usersTables u WHERE u.user_name = 'arun'";
			PreparedStatement preparedStmt1 = connection.prepareStatement(query1);
			ResultSet rs1 = preparedStmt1.executeQuery();
			
			while (rs1.next()) {
				System.out.println(rs1.getString("user_name"));
			}
			/*String query = "SELECT * FROM "+"Bar";

			PreparedStatement preparedStmt = connection.prepareStatement(query);
			//preparedStmt.setString(1, "582066");
			ResultSet rs = preparedStmt.executeQuery();
			
			ResultSetMetaData metaData = rs.getMetaData();
			
			List<Object> dynamicObjects = new ArrayList<>();
		
			
			while (rs.next()) {
				//System.out.println(rs.getString("id") +" :: " + rs.getString("name") );
				//System.out.println(rs.getString("id") +" :: " + rs.getString("name") + " :: "+ rs.getString("address"));
				
				System.out.println(rs.getString("Year") +" :: " + rs.getString("value1") + " :: "+ rs.getString("value2"));

			}*/
			
			//FieldColumnMapping(rs, metaData, dynamicObjects);

			stmt.close();
			connection.commit();
		} catch (SQLException e) {
			System.out.println("Exception Message " + e.getLocalizedMessage());
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			connection.close();
		}
	}


	private static void FieldColumnMapping(ResultSet rs, ResultSetMetaData metaData, List<Object> dynamicObjects)
			throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException,
			InvocationTargetException {
		while (rs.next()) {
			Object object = Class.forName("com.monsanto.model.SampleModel").newInstance();

			Class c = object.getClass();
			System.out.println("Package: " + c.getPackage() + "\nClass: " + c.getSimpleName() + "\nFull Identifier: "
					+ c.getName());
			
			Field[] allFields = object.getClass().getDeclaredFields();

			for (Field field : allFields) {
				if (checkTableColumnExitOrNotInResultSet(metaData, field.getName())) {
					BeanUtils.setProperty(object, field.getName(), rs.getString(field.getName()));
					System.out.println("Column Name ::" + field.getName() + " Column Value :: "
							+ rs.getString(field.getName()));
				}
			}

			dynamicObjects.add(object);

		}
	}

	
	private static boolean checkTableColumnExitOrNotInResultSet(ResultSetMetaData metaData, String columnName) {
		int numCol;
		try {
			numCol = metaData.getColumnCount();
			for (int i = 1; i < numCol + 1; i++) {
				if (metaData.getColumnName(i).equalsIgnoreCase(columnName)) {
					return true;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return false;

	}
	private static Connection getDBConnection() {
		Connection dbConnection = null;
		try {
			Class.forName(StringConstants.DB_DRIVER);
		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
		try {
			dbConnection = DriverManager.getConnection(StringConstants.DB_CONNECTION, StringConstants.DB_USER, StringConstants.DB_PASSWORD);
			return dbConnection;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return dbConnection;
	}

}
