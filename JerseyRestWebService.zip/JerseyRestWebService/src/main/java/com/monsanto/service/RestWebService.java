package com.monsanto.service;

import java.io.IOException;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.monsanto.common.StringConstants;
import com.monsanto.dao.AbstractDAOService;
import com.monsanto.dao.DAOFactory;

@Path("/service")
public class RestWebService {

	@GET
	@Path("/json")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Json> loadListOfJsonDBData(@QueryParam("ClassName") String className) throws IOException {

		AbstractDAOService daoService = DAOFactory.getFactory(StringConstants.PSQL_FACTORY_NAME);
		List<Json> dynamicDbObject = daoService.loadListOfJsonDatas(className);

		return dynamicDbObject;
	}

	@GET
	@Path("/listofdynamicjson")
	@Produces(MediaType.APPLICATION_JSON)
	public Response loadListOfJsonDBDataWithResponse(@QueryParam("ClassName") String className) throws IOException {

		AbstractDAOService daoService = DAOFactory.getFactory(StringConstants.PSQL_FACTORY_NAME);
		List<Json> dynamicDbObject = daoService.loadListOfJsonDatas(checkNULL(className));

		return Response.ok().entity(dynamicDbObject).header("Access-Control-Allow-Origin", "*").build();
	}

	@GET
	@Path("/dynamicjson1")
	@Produces(MediaType.APPLICATION_JSON)
	public Response loadListOfJsonDBDataWithResponse1(@QueryParam("ClassName") String className) throws IOException {

		AbstractDAOService daoService = DAOFactory.getFactory(StringConstants.PSQL_FACTORY_NAME);
		List<Json> dynamicDbObject = daoService.loadListOfJsonDatas(checkNULL(className));

		return Response.ok().entity(dynamicDbObject.get(0)).header("Access-Control-Allow-Origin", "*").build();
	}

	@GET
	@Path("/dynamicjson")
	@Produces(MediaType.APPLICATION_JSON)
	public Response loadDynamicJsonDBDataWithResponse(@QueryParam("ClassName") String className) throws IOException {

		AbstractDAOService daoService = DAOFactory.getFactory(StringConstants.PSQL_FACTORY_NAME);
		List<Json> dynamicDbObject = daoService.loadListOfJsonDatas(checkNULL(className));

		return Response.ok().entity(dynamicDbObject.get(0)).header("Access-Control-Allow-Origin", "*").build();
	}

	private String checkNULL(String params) {
		if (params == null) {
			params = "";
		}
		return params;
	}

}
