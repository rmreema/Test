package com.monsanto.common;

import java.io.FileInputStream;

public class CustomClassLoader extends ClassLoader {

    final String basePath = "/D:/Software/apache-tomcat-8.5.4/webapps/monsanto/WEB-INF/classes/"; 
    //="L:/ARUN PRAKASH/samples/RESTfulExample/target/classes/";

    @Override
    protected Class<?> findClass(final String name) throws ClassNotFoundException {
        String fullName = name.replace('.', '/');
        fullName += ".class";

        String path = basePath + fullName ;
        try {
            FileInputStream fis = new FileInputStream(path);
            byte[] data = new byte[fis.available()];
            fis.read(data);
            Class<?> res = defineClass(name, data, 0, data.length);
            fis.close();

            return res;
        } catch(Exception e) {
            return super.findClass(name);
        }
    }
}

