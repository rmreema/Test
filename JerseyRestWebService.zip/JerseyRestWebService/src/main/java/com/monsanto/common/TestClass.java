package com.monsanto.common;

public class TestClass {
	public static void main(String[] args) {
		
		Class<?> clazz;
		try {
			clazz = Class.forName("com.monsanto.model.DefectTrack", true, new CustomClassLoader());
			Object obj = clazz.newInstance();
			System.out.println(obj.toString());
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
