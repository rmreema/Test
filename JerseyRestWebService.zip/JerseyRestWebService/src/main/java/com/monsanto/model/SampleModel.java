package com.monsanto.model;

public class SampleModel {
	private String x;
	private String y;
	private String z;
	/**
	 * @return the x
	 */
	public String getX() {
		return x;
	}
	/**
	 * @param x the x to set
	 */
	public void setX(String x) {
		this.x = x;
	}
	/**
	 * @return the y
	 */
	public String getY() {
		return y;
	}
	/**
	 * @param y the y to set
	 */
	public void setY(String y) {
		this.y = y;
	}
	/**
	 * @return the z
	 */
	public String getZ() {
		return z;
	}
	/**
	 * @param z the z to set
	 */
	public void setZ(String z) {
		this.z = z;
	}

	
	public SampleModel() {
		// TODO Auto-generated constructor stub
	}
	/**
	 * @param x
	 * @param y
	 * @param z
	 */
	public SampleModel(String x, String y, String z) {
		super();
		this.x = x;
		this.y = y;
		this.z = z;
	}
	
	
}
