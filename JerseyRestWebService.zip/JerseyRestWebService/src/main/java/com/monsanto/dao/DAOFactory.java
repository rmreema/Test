package com.monsanto.dao;

import com.monsanto.common.StringConstants;

/**
 * @author 582066
 *
 */
public class DAOFactory {

	public static AbstractDAOService getFactory(String choice) {

		if (choice.equalsIgnoreCase(StringConstants.PSQL_FACTORY_NAME)) {
			return new PsqlDAOService();
		} 
		return null;
	}
}
