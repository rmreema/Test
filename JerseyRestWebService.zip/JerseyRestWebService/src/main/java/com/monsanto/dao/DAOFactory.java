package com.monsanto.dao;

import com.monsanto.common.StringConstants;

/**
 * @author 582066
 *
 */
public class DAOFactory {

	public static AbstractDAOService getFactory(String choice) {

		if (choice.equalsIgnoreCase(StringConstants.H2_DATABASE_NAME)) {
			return new H2DAOService();
		} else if (choice.equalsIgnoreCase(StringConstants.NEO4J_DATABASE_NAME)) {
			return new Neo4jDAOService();
		} 
		return null;
	}
}
