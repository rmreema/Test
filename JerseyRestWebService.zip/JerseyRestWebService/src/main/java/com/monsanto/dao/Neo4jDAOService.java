package com.monsanto.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.neo4j.driver.v1.AuthTokens;
import org.neo4j.driver.v1.Driver;
import org.neo4j.driver.v1.GraphDatabase;
import org.neo4j.driver.v1.Record;
import org.neo4j.driver.v1.Session;
import org.neo4j.driver.v1.StatementResult;
import org.neo4j.driver.v1.Value;

import com.monsanto.common.StringConstants;
import com.monsanto.service.Json;

/**
 * @author 582066
 *
 */
public class Neo4jDAOService extends AbstractDAOService {

	@Override
	public List<Json> loadListOfJsonDatas(String className) {

		List<Json> jsonList = new ArrayList<>();
		try {
			// Multiple Class Name are append on the Parameter
			String[] classNameSplit = className.split(",");

			for (String classNameObj : classNameSplit) {

				Json json = new Json();
				if (!"".equalsIgnoreCase(classNameObj)) {
					List<Object> dynamicObjects = new ArrayList<>();

					Driver driver = GraphDatabase.driver(StringConstants.NEO4J_DB_CONNECTION,
							AuthTokens.basic(StringConstants.NEO4J_DB_USER, StringConstants.NEO4J_DB_PASSWORD));
					
					Session session = driver.session();
					StatementResult result = session.run("MATCH (a:" + classNameObj + ")  RETURN *");

					while (result.hasNext()) {
						Record record = result.next();
						for (Value value : record.values()) {
							Map<String, Object> map = value.asMap();

							dynamicObjects.add(map);
						}

					}
					json.setElement(classNameObj);
					json.setData(dynamicObjects);

					session.close();
					driver.close();
				}
				jsonList.add(json);
			}

		} catch (Exception e) {
			System.out.println("Exception Message " + e.getLocalizedMessage());
		}
		return jsonList;

	}

}
