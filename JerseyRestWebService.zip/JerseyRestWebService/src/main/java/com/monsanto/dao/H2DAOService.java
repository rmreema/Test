package com.monsanto.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.monsanto.common.StringConstants;
import com.monsanto.service.Json;

/**
 * @author 582066
 *
 */
public class H2DAOService extends AbstractDAOService {

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.monsanto.dao.AbstractDAOService#loadListOfJsonDatas(java.lang.String)
	 */
	@Override
	public List<Json> loadListOfJsonDatas(String className) {

		List<Json> jsonList = new ArrayList<>();

		Connection connection = getDBConnection();
		Statement stmt = null;
		try {
			connection.setAutoCommit(false);
			stmt = connection.createStatement();

			// Multiple Class Name are append on the Parameter
			String[] classNameSplit = className.split(",");

			for (String classNameObj : classNameSplit) {

				Json json = new Json();
				if (!"".equalsIgnoreCase(classNameObj)) {
					List<Object> dynamicObjects = new ArrayList<>();

					String query = "SELECT * FROM " + classNameObj;
					PreparedStatement preparedStmt = connection.prepareStatement(query);

					ResultSet rs = preparedStmt.executeQuery();

					ResultSetMetaData rsmd = rs.getMetaData();
					int columnCount = rsmd.getColumnCount();

					while (rs.next()) {
						// Set the Column Field Mapping
						Map<String, String> map = new HashMap<>();
						for (int i = 1; i <= columnCount; i++) {
							String name = rsmd.getColumnName(i);
							map.put(name.toLowerCase(), rs.getString(name));
						}

						dynamicObjects.add(map);
					}
					json.setElement(classNameObj);
					json.setData(dynamicObjects);

				}
				jsonList.add(json);
			}

			stmt.close();
			connection.commit();

		} catch (SQLException e) {
			System.out.println("Exception Message " + e.getLocalizedMessage());
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return jsonList;

	}

	/**
	 * 
	 * This method is used for checking the model field is available on metadata
	 * 
	 * @param metaData
	 * @param columnName
	 * @return
	 */
	private boolean checkTableColumnExitOrNotInResultSet(ResultSetMetaData metaData, String columnName) {
		int numCol;
		try {
			numCol = metaData.getColumnCount();
			for (int i = 1; i < numCol + 1; i++) {
				if (metaData.getColumnName(i).equalsIgnoreCase(columnName)) {
					return true;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return false;

	}

	/**
	 * This method mainly used for creating connection
	 * 
	 * @return
	 */
	private static Connection getDBConnection() {
		Connection dbConnection = null;
		try {
			Class.forName(StringConstants.DB_DRIVER);
		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
		try {
			dbConnection = DriverManager.getConnection(StringConstants.DB_CONNECTION, StringConstants.DB_USER,
					StringConstants.DB_PASSWORD);
			return dbConnection;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return dbConnection;
	}

}
