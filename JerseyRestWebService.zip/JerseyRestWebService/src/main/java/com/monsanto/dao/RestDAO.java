package com.monsanto.dao;

import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;

import com.monsanto.common.StringConstants;
import com.monsanto.service.Json;

/**
 * @author 582066
 *
 */
public class RestDAO {

	/**
	 * @param className
	 * @param tableColumns
	 * @param filterBy
	 * @return
	 */
	public List<Object> loadDynamicObjectFromDB(String className, String tableColumns, String filterBy) {

		List<Object> dynamicObjects = new ArrayList<>();

		Connection connection = getDBConnection();
		Statement stmt = null;
		try {
			connection.setAutoCommit(false);
			stmt = connection.createStatement();

			Object classObject = Class.forName(className).newInstance();
			Class c = classObject.getClass();
			if ("".equalsIgnoreCase(tableColumns)) {
				tableColumns = "*";
			}
			String query = "SELECT " + tableColumns + " FROM " + c.getSimpleName() + " " + filterBy;

			PreparedStatement preparedStmt = connection.prepareStatement(query);

			ResultSet rs = preparedStmt.executeQuery();

			while (rs.next()) {
				Object object = Class.forName(className).newInstance();

				Field[] allFields = object.getClass().getDeclaredFields();

				for (Field field : allFields) {
					if (checkTableColumnExitOrNotInResultSet(rs.getMetaData(), field.getName())) {
						BeanUtils.setProperty(object, field.getName(), rs.getString(field.getName()));
						System.out.println("Column Name ::" + field.getName() + " Column Value :: "
								+ rs.getString(field.getName()));
					}
				}

				dynamicObjects.add(object);
			}

			stmt.close();
			connection.commit();

			stmt.close();
			connection.commit();
		} catch (SQLException e) {
			System.out.println("Exception Message " + e.getLocalizedMessage());
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return dynamicObjects;

	}

	private boolean checkTableColumnExitOrNotInResultSet(ResultSetMetaData metaData, String columnName) {
		int numCol;
		try {
			numCol = metaData.getColumnCount();
			for (int i = 1; i < numCol + 1; i++) {
				if (metaData.getColumnName(i).equalsIgnoreCase(columnName)) {
					return true;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return false;

	}

	private static Connection getDBConnection() {
		Connection dbConnection = null;
		try {
			Class.forName(StringConstants.DB_DRIVER);
		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
		try {
			dbConnection = DriverManager.getConnection(StringConstants.DB_CONNECTION, StringConstants.DB_USER,
					StringConstants.DB_PASSWORD);
			return dbConnection;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return dbConnection;
	}

	public List<Json> loadListOfJsonDatas(String className) {

		List<Json> jsonList = new ArrayList<>();

		Connection connection = getDBConnection();
		Statement stmt = null;
		try {
			connection.setAutoCommit(false);
			stmt = connection.createStatement();

			String[] classNameSplit = className.split(",");

			for (String classNameObj : classNameSplit) {
				Json json = new Json();
				List<Object> dynamicObjects = new ArrayList<>();

				/*Object classObject = Class.forName(classNameObj).newInstance();
				Class c = classObject.getClass();*/

				String fullClassName = StringConstants.PACKAGE_NAME + "." + classNameObj;
				String query = "SELECT * FROM " + classNameObj;

				PreparedStatement preparedStmt = connection.prepareStatement(query);

				ResultSet rs = preparedStmt.executeQuery();

				while (rs.next()) {
					Object object = Class.forName(fullClassName).newInstance();

					Field[] allFields = object.getClass().getDeclaredFields();

					for (Field field : allFields) {
						if (checkTableColumnExitOrNotInResultSet(rs.getMetaData(), field.getName())) {
							BeanUtils.setProperty(object, field.getName(), rs.getString(field.getName()));
							System.out.println("Column Name ::" + field.getName() + " Column Value :: "
									+ rs.getString(field.getName()));
						}
					}

					dynamicObjects.add(object);
				}
				json.setElement(classNameObj);
				json.setData(dynamicObjects);

				jsonList.add(json);

			}

			stmt.close();
			connection.commit();

		} catch (SQLException e) {
			System.out.println("Exception Message " + e.getLocalizedMessage());
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return jsonList;
	}
}
