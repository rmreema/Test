package com.monsanto.dao;

import java.util.List;

import com.monsanto.service.Json;

/**
 * @author 582066
 *
 */
public abstract class AbstractDAOService {

	public abstract List<Json> loadListOfJsonDatas(String className);
}
