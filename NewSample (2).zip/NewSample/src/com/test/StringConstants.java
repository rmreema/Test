package com.test;

/**
 * @author 582066
 *
 */
public class StringConstants {

	public static final String H2_DB_DRIVER = "org.h2.Driver";
	public static final String H2_DB_CONNECTION = "jdbc:h2:D:/dynamicobject";
	public static final String H2_DB_USER = "root";
	public static final String H2_DB_PASSWORD = "root";
	public static final int REST_DAO = 1;

	public static final String PACKAGE_NAME = "com.monsanto.model";
	public static final String H2_DATABASE_NAME = "H2";
	public static final String ROLE_NAME = "finance";
	public static final String ERR_PASSWORD = "Enter the Password";
	public static final String ERR_CONFIRM_PASSWORD = "Enter the Confirm Password";
	public static final String ERR_MISMATCH_PASSWORD = "Both Password is mismatch";
	public static final String ERR_USER_NAME = "Enter the User Name";

	public static final String NEO4J_DATABASE_NAME = "Neo4j";
	public static final String FACTORY_NAME = "Neo4j";

	public static final String NEO4J_DB_CONNECTION = "bolt://localhost";
	public static final String NEO4J_DB_USER = "neo4j";
	public static final String NEO4J_DB_PASSWORD = "root";

}
