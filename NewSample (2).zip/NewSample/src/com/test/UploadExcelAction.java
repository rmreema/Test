package com.test;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.SessionAware;

import com.monsanto.dao.AbstractDAOService;
import com.monsanto.dao.DAOFactory;
import com.monsanto.model.UserDetails;
import com.opensymphony.xwork2.ActionSupport;

public class UploadExcelAction extends ActionSupport implements SessionAware {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private File uploadFile;
	private String uploadFileContentType;
	private String uploadFileFileName;
	private String userName;
	private String roleName;
	private List<String> xCoordinateList;
	private List<String> yCoordinateList;
	private String chartType;
	private String selXCoordinate;
	private List<String> selYCoordinates;
	public String sheetName;
	HttpServletRequest request = ServletActionContext.getRequest();
	private Map<String, Object> session;
	private String key = null;
	UserDetails userDetails;
	private String statusMessage;

	// HellooAction
	private String name;
	private String password;
	private String role;
	private String jsonData;

	public String execute() {
		key = "Both";
		return SUCCESS;
	}

	public String uploadExcel() {
		try {
			File fileupload = getUploadFile();
			InputStream input = new BufferedInputStream(new FileInputStream(fileupload));
			POIFSFileSystem fs = new POIFSFileSystem(input);
			HSSFWorkbook workbook = new HSSFWorkbook(fs);
			HSSFSheet sheet = workbook.getSheetAt(0);

			sheetName = workbook.getSheetName(0);
			request = ServletActionContext.getRequest();
			session.put("sheetName", sheetName);

			Iterator<Row> rowIterator = sheet.iterator();
			List<Map<String, String>> maps = new ArrayList<>();
			Map<Integer, String> headerMap = new HashMap<>();

			while (rowIterator.hasNext()) {
				Row row = rowIterator.next();
				// For each row, iterate through each columns
				Iterator<Cell> cellIterator = row.cellIterator();

				Map<String, String> rowMap = new HashMap<>();
				while (cellIterator.hasNext()) {

					Cell cell = cellIterator.next();

					String cellValue = "";
					switch (cell.getCellType()) {

					case Cell.CELL_TYPE_NUMERIC:
						cellValue = new BigDecimal(cell.getNumericCellValue()).toString();
						// System.out.println("Cell Value :: " + cellValue);
						break;
					case Cell.CELL_TYPE_STRING:
						cellValue = cell.getStringCellValue();
						// System.out.println("Cell Value :: " + cellValue);
						break;
					case Cell.CELL_TYPE_BOOLEAN:
						// System.out.println("boolean===>>>" +
						break;
					}

					if (cell.getRowIndex() == 0) {
						headerMap.put(cell.getColumnIndex(), cellValue);

					} else {
						rowMap.put(headerMap.get(cell.getColumnIndex()), cellValue);
					}
				}
				// Skip the header row here
				if (row.getRowNum() != 0) {
					maps.add(rowMap);
				}
			}
			getCoordinates(headerMap);

			AbstractDAOService daoService = DAOFactory.getFactory(StringConstants.FACTORY_NAME);
			daoService.uploadExcelValuesIntoDB(maps, headerMap, sheetName);

			input.close();

		} catch (Exception e) {
			System.out.println(e.getMessage());
			return INPUT;

		}
		key = "upload";
		setKey(key);
		setStatusMessage("File Uploaded Successfully, Plese Select Coordinates for the type of Chart.");
		return SUCCESS;
	}

	public String loginAction() throws Exception {

		String pageName = "dashboard";

		AbstractDAOService daoService = DAOFactory.getFactory(StringConstants.FACTORY_NAME);
		userDetails = daoService.validateCredentials(name, password);

		session.put("loginedUser", userDetails);
		session.put("role", userDetails.getRole());

		if (userDetails.getName() != null && userDetails.getName().equals(name) && userDetails.getPassword() != null
				&& userDetails.getPassword().equals(password)) {
			role = userDetails.getRole();
			pageName = "dashboard";

		} else if (userDetails.getName() == null && userDetails.getPassword() == null) {
			setStatusMessage("Invalid login credentials, please try again.");
			pageName = ERROR;
		} else {
			pageName = ERROR;
			setStatusMessage("Exception Hasbeen Occured, please try again.");
		}
		return pageName;
	}

	private void getCoordinates(Map<Integer, String> headerMap) {

		List<String> xCoordinateList = new ArrayList<String>();
		List<String> yCoordinateList = new ArrayList<String>();

		for (int i = 0; i < headerMap.size(); i++) {
			if (i == 0) {
				xCoordinateList.add(headerMap.get(i));
			} else {
				yCoordinateList.add(headerMap.get(i));
			}
		}
		setxCoordinateList(xCoordinateList);
		setyCoordinateList(yCoordinateList);
	}

	public String getWidgetDetails() {

		UserDetails userDetails = (UserDetails) session.get("loginedUser");
		String chartName;

		if (chartType.equals("1"))
			chartName = "Bar";
		else if (chartType.equals("2"))
			chartName = "Area";
		else if(chartType.equals("3"))
		    chartName ="Line";
		else 
		    chartName="Table"; 

		AbstractDAOService daoService = DAOFactory.getFactory(StringConstants.FACTORY_NAME);
		daoService.saveWidgetDetails(userDetails, chartName, getSelXCoordinate(), getSelYCoordinates().toString(),
				session.get("sheetName").toString());

		setStatusMessage("Chart details updated successfully.");
		request.setAttribute("StatusMessage", getStatusMessage());

		return SUCCESS;
	}

	public List<String> getxCoordinateList() {
		return xCoordinateList;
	}

	public void setxCoordinateList(List<String> xCoordinateList) {
		this.xCoordinateList = xCoordinateList;
	}

	public List<String> getyCoordinateList() {
		return yCoordinateList;
	}

	public void setyCoordinateList(List<String> yCoordinateList) {
		this.yCoordinateList = yCoordinateList;
	}

	public String getChartType() {
		return chartType;
	}

	public void setChartType(String chartType) {
		this.chartType = chartType;
	}

	public String getSelXCoordinate() {
		return selXCoordinate;
	}

	public void setSelXCoordinate(String selXCoordinate) {
		this.selXCoordinate = selXCoordinate;
	}

	public List<String> getSelYCoordinates() {
		return selYCoordinates;
	}

	public void setSelYCoordinates(List<String> selYCoordinates) {
		this.selYCoordinates = selYCoordinates;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public File getUploadFile() {
		return uploadFile;
	}

	public void setUploadFile(File uploadFile) {
		this.uploadFile = uploadFile;
	}

	public String getUploadFileContentType() {
		return uploadFileContentType;
	}

	public void setUploadFileContentType(String uploadFileContentType) {
		this.uploadFileContentType = uploadFileContentType;
	}

	public String getUploadFileFileName() {
		return uploadFileFileName;
	}

	public void setUploadFileFileName(String uploadFileFileName) {
		this.uploadFileFileName = uploadFileFileName;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getStatusMessage() {
		return statusMessage;
	}

	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getJsonData() {
		return jsonData;
	}

	public void setJsonData(String jsonData) {
		this.jsonData = jsonData;
	}

	@Override
	public void setSession(Map<String, Object> session) {
		this.session = session;
	}
}
