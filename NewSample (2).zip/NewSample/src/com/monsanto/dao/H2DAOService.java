package com.monsanto.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.monsanto.model.UserDetails;
import com.test.Database;
import com.test.StringConstants;

/**
 * @author 582066
 *
 */
public class H2DAOService extends AbstractDAOService {

	@Override
	public UserDetails validateCredentials(String userName, String password) {

		UserDetails userDetails = new UserDetails();
		Connection connection = getDBConnection();
		Statement stmt = null;
		try {
			connection.setAutoCommit(false);
			stmt = connection.createStatement();

			String query2 = "SELECT u.user_name,u.user_pass,r.role_name FROM  user_roles r,usersTables u WHERE u.user_name = r.user_name AND u.user_name =?"
					+ "and u.user_pass=?";
			PreparedStatement preparedStmt = connection.prepareStatement(query2);
			preparedStmt.setString(1, userName);
			preparedStmt.setString(2, password);
			ResultSet rs = preparedStmt.executeQuery();

			while (rs.next()) {
				userDetails.setName(rs.getString("user_name"));
				userDetails.setPassword(rs.getString("user_pass"));
				userDetails.setRole(rs.getString("role_name"));
			}
			stmt.close();
			connection.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return userDetails;
	}

	/**
	 * This method mainly used for creating connection
	 * 
	 * @return
	 */
	private static Connection getDBConnection() {
		Connection dbConnection = null;
		try {
			Class.forName(StringConstants.H2_DB_DRIVER);
		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
		try {
			dbConnection = DriverManager.getConnection(StringConstants.H2_DB_CONNECTION, StringConstants.H2_DB_USER,
					StringConstants.H2_DB_PASSWORD);
			return dbConnection;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return dbConnection;
	}

	@Override
	public String addUserDetails(String userName, String password, String role) {

		Connection connection = getDBConnection();
		try {
			connection.setAutoCommit(false);
			PreparedStatement preparedStatement = null;
			String sqlQuery = "insert into usersTables values(?,?)";
			preparedStatement = connection.prepareStatement(sqlQuery);
			preparedStatement.setString(1, userName);
			preparedStatement.setString(2, password);

			preparedStatement.executeUpdate();

			PreparedStatement preparedStatement1 = null;
			String sqlQuery1 = "insert into user_roles values(?,?)";
			preparedStatement1 = connection.prepareStatement(sqlQuery1);
			preparedStatement1.setString(1, userName);
			preparedStatement1.setString(2, role);

			preparedStatement1.executeUpdate();
			connection.commit();

		} catch (SQLException e) {
			System.out.println("Exception Message " + e.getLocalizedMessage());
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		}
		return "success";
	}

	@Override
	public void saveWidgetDetails(UserDetails userDetails, String chartName, String xCoOrdinate, String yCoOrdinate,
			String sheetName) {

		Connection dbConnection = Database.getDBConnection();
		PreparedStatement preparedStatement = null;
		try {
			String sqlQuery = "insert into Widget(chartType,xkeys,ykeys,title,role) values(?,?,?,?,?)";

			System.out.println("Inserted widget Details: " + chartName + " " + xCoOrdinate + " " + yCoOrdinate + " "
					+ sheetName + " " + userDetails.getRole());

			preparedStatement = dbConnection.prepareStatement(sqlQuery);
			preparedStatement.setString(1, chartName);
			preparedStatement.setString(2, xCoOrdinate);
			preparedStatement.setString(3, yCoOrdinate);
			preparedStatement.setString(4, sheetName);
			preparedStatement.setString(5, userDetails.getRole());

			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				dbConnection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}

	@Override
	public void uploadExcelValuesIntoDB(List<Map<String, String>> maps, Map<Integer, String> headerMap,
			String sheetName) {

		List<String> headers = new ArrayList<>();
		headers.addAll(headerMap.values());

		StringBuffer createTable = new StringBuffer();
		createTable.append("CREATE TABLE " + sheetName + "( ");

		StringBuffer insertScriptBuffer = new StringBuffer();
		insertScriptBuffer.append("INSERT INTO " + sheetName + "( ");

		StringBuffer appendPreparedStmt = new StringBuffer();

		Map<String, Integer> preparedStmtString = new HashMap<>();
		int i = 1;
		for (String header : headers) {

			if (headers.size() == i) {
				System.out.println("Last list value :: " + header);
				createTable.append(header + " varchar(255) )");

				appendPreparedStmt.append("? )");
				insertScriptBuffer.append(header + " ) VALUES ( " + appendPreparedStmt.toString());
			} else {
				System.out.println(header);
				createTable.append(header + " varchar(255) , ");

				insertScriptBuffer.append(header + " ,");
				appendPreparedStmt.append("?,");
			}
			preparedStmtString.put(header, i);

			i++;
		}
		System.out.println("Create Table script :: " + createTable.toString());
		System.out.println("Insert Script  :: " + insertScriptBuffer.toString());

		Connection connection = Database.getDBConnection();
		Statement stmt = null;
		try {
			connection.setAutoCommit(false);
			stmt = connection.createStatement();

			// Table has been created here
			stmt.execute(createTable.toString());

			for (Map<String, String> map : maps) {

				PreparedStatement preparedStmt = connection.prepareStatement(insertScriptBuffer.toString());

				for (Entry<String, String> obj : map.entrySet()) {
					System.out.println(preparedStmtString.get(obj.getKey()) + " - " + obj.getValue());
					preparedStmt.setString(preparedStmtString.get(obj.getKey()), obj.getValue());
				}
				preparedStmt.executeUpdate();
				preparedStmt.close();
			}

			stmt.close();
			connection.commit();

		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}

}
