package com.monsanto.dao;

import java.util.List;
import java.util.Map;

import com.monsanto.model.UserDetails;

/**
 * @author 582066
 *
 */
public abstract class AbstractDAOService {

	public abstract String addUserDetails(String userName, String password, String role);

	public abstract UserDetails validateCredentials(String userName, String password);

	public abstract void saveWidgetDetails(UserDetails userDetails, String chartName, String xCoOrdinate,
			String yCoOrdinate, String sheetName);

	public abstract void uploadExcelValuesIntoDB(List<Map<String, String>> maps, Map<Integer, String> headerMap,String sheetName);

}
