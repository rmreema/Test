package com.monsanto.dao;

import java.util.List;
import java.util.Map;

import org.neo4j.driver.v1.AuthTokens;
import org.neo4j.driver.v1.Driver;
import org.neo4j.driver.v1.GraphDatabase;
import org.neo4j.driver.v1.Record;
import org.neo4j.driver.v1.Session;
import org.neo4j.driver.v1.StatementResult;

import com.monsanto.model.UserDetails;
import com.test.StringConstants;

/**
 * @author 582066
 *
 */
public class Neo4jDAOService extends AbstractDAOService {

	@Override
	public UserDetails validateCredentials(String userName, String password) {

		UserDetails userDetails = new UserDetails();

		Driver driver = GraphDatabase.driver(StringConstants.NEO4J_DB_CONNECTION,
				AuthTokens.basic(StringConstants.NEO4J_DB_USER, StringConstants.NEO4J_DB_PASSWORD));

		Session session = driver.session();

		StatementResult result = session.run("MATCH (a:users {username:'" + userName
				+ "'})-[:RSHIP]->(roles) RETURN a.username AS username,a.password AS password ,roles.role AS role");
		while (result.hasNext()) {
			Record record = result.next();

			Map<String, Object> maps = record.asMap();

			userDetails.setName(maps.get("username").toString());
			userDetails.setPassword(maps.get("password").toString());
			userDetails.setRole(maps.get("role").toString());

			System.out.println(maps.keySet());
			System.out.println(maps.values());

		}

		session.close();
		driver.close();

		return userDetails;
	}

	@Override
	public String addUserDetails(String userName, String password, String role) {

		try {

			Driver driver = GraphDatabase.driver(StringConstants.NEO4J_DB_CONNECTION,
					AuthTokens.basic(StringConstants.NEO4J_DB_USER, StringConstants.NEO4J_DB_PASSWORD));
			Session session = driver.session();

			String userQuery = "CREATE (a:users {username:'" + userName + "',password:'" + password + "'})";

			String roleQuery = "MATCH (a:users{username:'" + userName
					+ "'}) CREATE (a) - [rship:RSHIP] ->(role:ROLE {role:'" + role + "'}) RETURN a ,rship,role ";

			session.run(userQuery);
			session.run(roleQuery);

			session.close();
			driver.close();

		} catch (Exception e) {
			System.out.println("Exception Message " + e.getLocalizedMessage());
		}
		return "success";
	}

	@Override
	public void saveWidgetDetails(UserDetails userDetails, String chartName, String xCoOrdinate, String yCoOrdinate,
			String sheetName) {
		try {

			Driver driver = GraphDatabase.driver(StringConstants.NEO4J_DB_CONNECTION,
					AuthTokens.basic(StringConstants.NEO4J_DB_USER, StringConstants.NEO4J_DB_PASSWORD));
			Session sessions = driver.session();

			StringBuffer createTable = new StringBuffer();
			createTable.append("CREATE (a:Widget {chartType:'" + chartName + "',xkeys:'" + xCoOrdinate + "' ,ykeys:'"
					+ yCoOrdinate + "' ,title:'" + sheetName + "' ,role:'" + userDetails.getRole() + "'})");

			System.out.println(createTable.toString());

			sessions.run(createTable.toString());
			sessions.close();
			driver.close();

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	@Override
	public void uploadExcelValuesIntoDB(List<Map<String, String>> maps, Map<Integer, String> headerMap,
			String sheetName) {

		Driver driver = GraphDatabase.driver(StringConstants.NEO4J_DB_CONNECTION,
				AuthTokens.basic(StringConstants.NEO4J_DB_USER, StringConstants.NEO4J_DB_PASSWORD));
		Session session = driver.session();

		for (Map<String, String> mapObj : maps) {

			StringBuffer createTable = new StringBuffer();
			createTable.append("CREATE ( a:" + sheetName + "{ ");
			int i = 1;
			for (Map.Entry<String, String> map : mapObj.entrySet()) {
				if (mapObj.size() == i) {
					createTable.append(map.getKey() + ":'" + map.getValue() + "' })");
				} else {
					createTable.append(map.getKey() + ":'" + map.getValue() + "',");
				}
				i++;
			}
			System.out.println(createTable.toString());
			session.run(createTable.toString());
		}

		session.close();
		driver.close();

	}
}
