package com.monsanto.model;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.FileInputStream;

import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtField;
import javassist.bytecode.AccessFlag;
import javassist.bytecode.ClassFile;

public class ObjectCreation {

	final static String basePath = "/D:/Software/apache-tomcat-8.5.4/webapps/monsanto/WEB-INF/classes/";

	public static void main(String[] args) {

		String name = "com.monsanto.model.Demo";
		try {

			String fullName = name.replace('.', '/');
			fullName += ".class";

			String path = basePath + fullName;
			FileInputStream fis = new FileInputStream(path);
			BufferedInputStream fin = new BufferedInputStream(fis);
			ClassFile cf = new ClassFile(new DataInputStream(fin));

			
			ClassPool p = ClassPool.getDefault();
			p.insertClassPath(basePath);
			CtClass cc1 = p.get("com.monsanto.model.DefectTrack");
			
			
			System.out.println(cc1.getSimpleName()+""+cc1.getName());
			ClassPool pool = ClassPool.getDefault();
			CtClass cc = pool.makeClass(cc1.getName());
			
		for (CtField obj: cc1.getFields()) {
				CtField fcolumn1 = new CtField(obj, cc);
				fcolumn1.setModifiers(AccessFlag.PUBLIC);
				cc.addField(fcolumn1);
			}
			
		System.out.println("");
		
			/*for (CtMethod obj : cc1.getMethods()) {
				 CtMethod  method = CtNewMethod.copy(obj, cc, null);
				
				cc.addMethod(method);
			}
			
			Class<?> cClass = cc.toClass();
			Object o = cClass.newInstance();*/
		
			 System.out.println("");
			

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}