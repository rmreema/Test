package com.monsanto.model;

public class Model {
	public String getModel() {
		return Model;
	}

	public void setModel(String s) {
		Model = s;
	}

	public String getId() {
		return id;
	}

	public void setId(String s) {
		id = s;
	}

	public String getName() {
		return name;
	}

	public void setName(String s) {
		name = s;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String s) {
		desc = s;
	}

	public String Model;
	public String id;
	public String name;
	String desc;
}
