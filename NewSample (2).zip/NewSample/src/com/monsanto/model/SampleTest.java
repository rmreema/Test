package com.monsanto.model;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;

import javassist.CannotCompileException;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtField;
import javassist.CtMethod;
import javassist.bytecode.AccessFlag;
import javassist.bytecode.ClassFile;

public class SampleTest {

	public static void main(String[] args) throws Exception {
		
		ClassPool pool = ClassPool.getDefault();
		CtClass cc = pool.makeClass("com.monsanto.model.Testing");
		CtClass column1cls;
		try {
			column1cls = ClassPool.getDefault().get("java.lang.String");
			CtField fcolumn1;
			fcolumn1 = new CtField(column1cls, "a", cc);
			fcolumn1.setModifiers(AccessFlag.PUBLIC);
			cc.addField(fcolumn1);
			cc.addMethod(generateGetter(cc,"a", java.lang.String.class));
			cc.addMethod(generateSetter(cc, "a", java.lang.String.class));
			
			ClassFile ccFile = cc.getClassFile();
		
			 Class h = cc.toClass();
			 Object o = h.newInstance();
			 System.out.println(o.toString());

		} catch (Exception e) { 
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	private static CtMethod generateGetter(CtClass declaringClass, String fieldName, Class fieldClass)
			throws CannotCompileException {

		String getterName = "get" + fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1);
		System.out.println("GetterName---" + getterName);
		StringBuffer sb = new StringBuffer();
		sb.append("public ").append(fieldClass.getName()).append(" ").append(getterName).append("() { ")
				.append("return  " + fieldName + ";").append("}");
		return CtMethod.make(sb.toString(), declaringClass);

	}

	private static CtMethod generateSetter(CtClass declaringClass, String fieldName, Class fieldClass)
			throws CannotCompileException {

		String setterName = "set" + fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1);
		System.out.println("setterName------" + setterName);
		StringBuffer sb = new StringBuffer();
		sb.append("public void ").append(setterName).append("").append("(").append(fieldClass.getName()).append(" ")
				.append(fieldName).append(")").append("{ ").append("this.").append(fieldName).append("=")
				.append(fieldName).append(";").append("}");
		System.out.println("SB TO String " + sb.toString());
		return CtMethod.make(sb.toString(), declaringClass);

	}
}
