package com.monsanto.dashboard;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.monsanto.dao.AbstractDAOService;
import com.monsanto.dao.DAOFactory;
import com.opensymphony.xwork2.ActionSupport;
import com.test.StringConstants;

/**
 * @author 582066
 *
 */
public class AddUserDetailsAction extends ActionSupport {

	private String userName = "";
	private String password = "";
	private String confirmPassword = "";
	private String role = "";

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName
	 *            the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password
	 *            the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return the confirmPassword
	 */
	public String getConfirmPassword() {
		return confirmPassword;
	}

	/**
	 * @param confirmPassword
	 *            the confirmPassword to set
	 */
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	/**
	 * @return the role
	 */
	public String getRole() {
		return role;
	}

	/**
	 * @param role
	 *            the role to set
	 */
	public void setRole(String role) {
		this.role = role;
	}

	public String addUserDetails() {
		String returnString = "error";

		if ("".equalsIgnoreCase(userName)) {
			addFieldError("userName", StringConstants.ERR_USER_NAME);
		} else if ("".equalsIgnoreCase(password)) {
			addFieldError("password", StringConstants.ERR_PASSWORD);
		} else if ("".equalsIgnoreCase(role)) {
			addFieldError("role", StringConstants.ERR_PASSWORD);
		} else {
			AbstractDAOService daoService = DAOFactory.getFactory(StringConstants.FACTORY_NAME);
			daoService.addUserDetails(userName, password, role);

		}
		return returnString;
	}

	public String userDetails() {

		return "success";
	}

	private static Connection getDBConnection() {
		Connection dbConnection = null;
		try {
			Class.forName(StringConstants.H2_DB_DRIVER);
		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
		try {
			dbConnection = DriverManager.getConnection(StringConstants.H2_DB_CONNECTION, StringConstants.H2_DB_USER,
					StringConstants.H2_DB_PASSWORD);
			return dbConnection;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return dbConnection;
	}
}
