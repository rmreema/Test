var ResultData;
var txt = '';
var script = '<script>';
// var script;
// var Role = 'pm';
var paramtest = 'ClassName=';
var chart_name;
var filter_data;



var config = {
	// data: test_data,
	// xkey : 'year',
	// ykeys : [ 'value1', 'value2', 'value3', 'value4', 'value5' ],
	// xkey : 'y',
	// ykeys : [ 'a', 'b'],
	//labels : [ 'Total Income', 'Total Outcome' ],
	fillOpacity : 0.6,
	hideHover : 'auto',
	resize : true,
	pointFillColors : [ '#0b62a4' ],
	pointStrokeColors : [ 'black' ],
	lineColors : [ 'gray', '#0b62a4' ],
	pointSize : 2

};

function loadProc(jsondata, ChartType, Title, xkey, ykeys) {

	txt = "<div class=\"col-lg-6\"><div class=\"panel panel-green\"><div class=\"panel-heading\"><h3 class=\"panel-title\"><i class=\"fa fa-long-arrow-right\"></i>";
	script = '<script>';
	script = script + " config.element=\'";

	if (ChartType == "Area") {
		ChartName = "area-chart";
		script = script + ChartName + "\';" + "Morris.Area(config);";
	} else if (ChartType == "Bar") {
		ChartName = "bar-chart";
		script = script + ChartName + "\';" + "Morris.Bar(config);";
	} else {
		ChartName = "line-chart";
		script = script + ChartName + "\';" + "Morris.Line(config);";
	}
	script = script + "</script>";

	config.data = jsondata;
	config.xkey = xkey;
	config.ykeys = ykeys;
	config.labels = ykeys;

	console.log("IN LOAD PROC.. JSONDATA: " + JSON.stringify(config.data)
			+ "XKEY " + config.xkey + " YKEYS: " + config.ykeys
			+ " CHART NAME: " + ChartName + " TITLE: " + Title);
	
	txt = txt + Title + "</h3>" + "</div>" + "<div class=\"panel-body\">" +"<div id=\"" + ChartName + "\"></div></div></div></div>";
	$('#chart-enclose').append(txt);
	$(document.body).append(script);

}

function loadTable(data, title) {
	var headerRow;
	var row;

	var tableDiv = "<div class=\"col-md-4\"> <div class=\"panel panel-green\"><div class=\"panel-heading\"><h3 class=\"panel-title\">" + title + "</h3></div>" +
	"<div class=\"box-body\" id=\"" + title + "\"></div></div></div>";
	
	$('#table-enclose').append(tableDiv);
	$("#"+title)
	.append(
			'<table class="table table-bordered table-hover table-style" id="' +title+ '1"></table>');
	
	var table = $("#"+title).children();
	var i = 1;
	$.each(data, function(idx, obj) {
		
		row = '<tr>';
		if (i == 1) {
			headerRow ='<thead><tr>';
			$.each(obj, function(k, v) {
				headerRow += '<th>' + k + '</th>';
				row += '<td>' + v + '</td>';
			});
			headerRow += '</tr></thead>';
			table.append(headerRow);
			i++;
		} else {

			$.each(obj, function(k, v) {
				row += '<td>' + v + '</td>';
			});

		}
		row += '</tr>';
		
		table.append(row);

	});
	$("#"+title+"1").DataTable();
}


function loadData(roleData) {
	$
			.each(
					roleData,
					function(idx, val) {
						paramtest = paramtest + val.title;
						chart_name = val.charttype;

						console.log("TITLE: " + paramtest + " CHART NAME: "
								+ chart_name + " YKEYS: " + config.ykeys
								+ "paramtest: " + paramtest);

						$
								.ajax({
									type : "GET",
									url : "http://localhost:8080/JerseyRestWebService/rest/service/dynamicjson",
									data : paramtest,
									dataType : "json",
									success : function(json) {
										var a = val.ykeys.replace("[", "")
												.replace("]", "").replace(
														/\s+/gm, "").split(',');
/*										if(val.chartType == "table"){
											loadTable(json.data, val.title);
											
										}*/
							//			else{
										loadProc(json.data, val.chartType,
												val.title, val.xkeys, a);
						//				}

									},
									error : function(e) {
									}
								});
						paramtest = 'ClassName=';

					});
}

$(document)
		.ready(
				function() {

					$('#AreaChart').append(txt);
					$('#AreaChart').append(script);

					$
							.ajax({
								type : "GET",
								url : "http://localhost:8080/JerseyRestWebService/rest/service/dynamicjson",
								data : "ClassName=Widget",
								dataType : "json",
								success : function(json1) {
									
									filter_data = json1.data
											.filter(function(el) {
												return el.role == roleName;

											});

									
									loadData(filter_data);
								},
								error : function(e) {
								}
							});

				});
