package com.test;

import java.io.BufferedInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;

import com.opensymphony.xwork2.ActionSupport;

import javassist.CannotCompileException;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtField;
import javassist.CtMethod;
import javassist.bytecode.AccessFlag;
import javassist.bytecode.ClassFile;

public class HelloAction extends ActionSupport{
 
	
	
	private static final long serialVersionUID = 1L;
 
	private File uploadFile;
	private String uploadFileContentType;
	private String uploadFileFileName;	
 
	public File getUploadFile() {
		return uploadFile;
	}
	public void setUploadFile(File uploadFile) {
		this.uploadFile = uploadFile;
	}
 
	public String getUploadFileContentType() {
		return uploadFileContentType;
	}
	public void setUploadFileContentType(String uploadFileContentType) {
		this.uploadFileContentType = uploadFileContentType;
	}
 
	public String getUploadFileFileName() {
		return uploadFileFileName;
	}
	public void setUploadFileFileName(String uploadFileFileName) {
		this.uploadFileFileName = uploadFileFileName;
	}
 
	public String execute()
	{
		
		HSSFCell column1=null;		
		HSSFCell column2=null;
		HSSFCell column3=null;
		try{
		//'String filePath = "c:/Myuploads";  // Path where uploaded file will be stored
       // System.out.println("Server path:" + filePath); // check your path in console
        //File fileToCreate = new File(filePath, uploadFileFileName);// Create file name  same as original
        //FileUtils.copyFile(uploadFile, fileToCreate); // Just copy temp file content tos this file		
			
        File fileupload= getUploadFile();
        
        //
        
        try{
            List list=new ArrayList();	
            //String fileName="d:\\menu.xls";
           // File file=new File(fileName);
            InputStream input = new BufferedInputStream(new FileInputStream(fileupload));
            POIFSFileSystem fs = new POIFSFileSystem( input );
            HSSFWorkbook wb = new HSSFWorkbook(fs);
            HSSFSheet sheet = wb.getSheetAt(0);
          //int i=0;
         Iterator rows=sheet.rowIterator();
         while(rows.hasNext()){
             HSSFRow row=(HSSFRow)rows.next();
              column1=row.getCell(0);
              column2=row.getCell(1);
              column3=row.getCell(2);
             
             System.out.println("\n");
             Iterator cells=row.cellIterator();
             while( cells.hasNext() ) {
                 HSSFCell cell = (HSSFCell) cells.next();
                 if(HSSFCell.CELL_TYPE_STRING==cell.getCellType()){
                	 
                	 System.out.println("======================"+cell.getStringCellValue());
                	 //column1=cell.getStringCellValue();
                	 
                // list.add(cell.getNumericCellValue());
                	 
                 }
                 else if (HSSFCell.CELL_TYPE_STRING==cell.getCellType()){
                	 System.out.println("===============222222222======="+cell.getStringCellValue());
                    // column2=cell.getStringCellValue();
                     //list.add(cell.getStringCellValue());

                 }
                 else
                     if (HSSFCell.CELL_TYPE_STRING==cell.getCellType()){
                    	// column3=cell.getStringCellValue();
                     //list.add(cell.getBooleanCellValue());

                     }
                     else
                         if(HSSFCell.CELL_TYPE_BLANK==cell.getCellType()){
                             System.out.print( "BLANK     " );}
                             else
                         System.out.print("Unknown cell type");

             }
             
                 //insertRowInDB(list);

         }
         System.out.println("column1 val------" + column1);
        
         
        System.out.println(list);
        }catch(Exception e){
            e.printStackTrace();
        }
        
        
        
        
        //
        ClassPool pool = ClassPool.getDefault();
       	CtClass cc= pool.makeClass("test");
   		CtClass column1cls = ClassPool.getDefault().get("java.lang.String");
   		CtField fcolumn1 = new CtField(column1cls, column1.toString(), cc);
   		fcolumn1.setModifiers(AccessFlag.PUBLIC);		
   		cc.addField(fcolumn1);
   		
   		System.out.println("column2 val------" + column2);
   		
   		CtClass column2cls = ClassPool.getDefault().get("java.lang.String");
   		CtField fcolumn2cls = new CtField(column2cls, column2.toString(), cc);
   		fcolumn2cls.setModifiers(AccessFlag.PUBLIC);		
   		cc.addField(fcolumn2cls);
   		
   		CtClass column3cls = ClassPool.getDefault().get("java.lang.String");
   		CtField fcolumn3cls = new CtField(column3cls, column3.toString(), cc);
   		fcolumn3cls.setModifiers(AccessFlag.PUBLIC);		
   		cc.addField(fcolumn3cls);
   		
   		cc.addMethod(generateGetter(cc, column1.toString(), java.lang.String.class));
   		cc.addMethod(generateSetter(cc, column1.toString(), java.lang.String.class));
   		
   		cc.addMethod(generateGetter(cc, column2.toString(), java.lang.String.class));
   		cc.addMethod(generateSetter(cc, column2.toString(), java.lang.String.class));
   		

   		cc.addMethod(generateGetter(cc, column3.toString(), java.lang.String.class));
   		cc.addMethod(generateSetter(cc, column3.toString(), java.lang.String.class));
   		File fpath = new File("C:\\apache-tomcat-8.5.4\\webapps\\NewTest\\WEB-INF\\classes\\com\\test\\"+column1+".class");
   		//File f = new File("/webapps/"+"Excel"+".class");
   		ClassFile ccFile = cc.getClassFile();
   		ccFile.write(new DataOutputStream(new FileOutputStream(fpath)));
         
        
		}catch(Exception e)
		{
			e.printStackTrace();
            addActionError(e.getMessage());
            return INPUT;
 
		}
		return SUCCESS;
	}
	
	private static CtMethod generateGetter(CtClass declaringClass,String fieldName,Class fieldClass) throws CannotCompileException{
        
        String getterName ="get"+fieldName.substring(0,1).toUpperCase()+fieldName.substring(1);
        System.out.println("GetterName---"+getterName);
        StringBuffer sb= new StringBuffer();
        sb.append("public ").append(fieldClass.getName()).append(" ").append(getterName).append("() { ").append("return  " +fieldName+";").append("}");
        return  CtMethod.make(sb.toString(),declaringClass);
        
 }

private static CtMethod generateSetter(CtClass declaringClass,String fieldName,Class fieldClass) throws CannotCompileException{
 
 String setterName ="set"+fieldName.substring(0,1).toUpperCase()+fieldName.substring(1);
 System.out.println("setterName------" + setterName);
 StringBuffer sb= new StringBuffer();
 sb.append("public void ").append(setterName).append("").append("(").append(fieldClass.getName()).append(" ").append(fieldName).append(")").append("{ ").append("this.").append(fieldName).append( "=").append(fieldName).append(";").append("}");
 System.out.println("SB TO String " + sb.toString());
 return  CtMethod.make(sb.toString(),declaringClass);
 
}

 
}

