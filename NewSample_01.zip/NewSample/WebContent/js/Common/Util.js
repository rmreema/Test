var ResultData;
var txt='';
var script='<script>';
//var script;
var Role='Admin';
var paramtest='ClassName=';
var chart_name;

var  config = {
         // data: test_data,
			xkey: 'year',
			ykeys: ['value1', 'value2','value3','value4','value5'],
            labels: ['Total Income', 'Total Outcome'],
            fillOpacity: 0.6,
            hideHover: 'auto',
            behaveLikeLine: true,
            resize: true,
            pointFillColors:['#ffffff'],
            pointStrokeColors: ['black'],
            lineColors:['red','green']
		
        };


function loadProc(jsondata, ChartName)
{txt='';
script='<script>';
		    	xml = $($.parseXML($('#XMLData').text()));
	    	 $(xml).find('widget').each(function(index,value){


	    	 if (($(this).find('Role').text()==Role) && ($(this).find('Title').text()== ChartName))
	    		 {
			
				config.data = jsondata;
	    		 var Title="<h1>"+$(this).find('Title').text()+"</h1>"
	    		 var ChartType= "<div id=\""+$(this).find('Title').text()+"\"></div>";
	    		 txt=txt+Title+ChartType;
	    		 script=script+" config.element=\'"+$(this).find('Title').text()+"\';";
				 
    		
	    		 if($(this).find('ChartType').text()=="AreaChart")
	    			 script=script+"Morris.Area(config);"; 
				 
	    		 else if($(this).find('ChartType').text()=="BarChart")
	    			 script=script+"Morris.Bar(config);"; 
	    		 else
	    			 script=script+"Morris.Line(config);";  
				 script=script+"</script>";
	    		 }
	    	
	    	  });
	    	
			
	    	 
$('#AreaChart').append(txt);
$(document.body).append(script);
	
}

$(document).ready(function(){
 $('#AreaChart').append(txt);
$('#AreaChart').append(script);	

	xml = $($.parseXML($('#XMLData').text()));
	 $(xml).find('widget').each(function(index,value){


	 if ($(this).find('Role').text()==Role)
		 {
		 	 paramtest=paramtest+$(this).find('Title').text();
			 chart_name=$(this).find('Title').text();
	var jsonData ;
		 
	$.ajax({  
	    type: "GET",  
	    url: "http://10.219.161.21:8080/JerseyRestWebService/rest/service/dynamicjson", 
	    data: paramtest,
	    dataType: "json", 
	    success: function(json){  
	    	console.log(JSON.stringify(json.data));
			loadProc(json.data,json.element);
	    	 
	      },  
	      error: function(e){  
	      } 
	  });
	  paramtest='ClassName=';
			 
		 }
	 });
	
 
});

