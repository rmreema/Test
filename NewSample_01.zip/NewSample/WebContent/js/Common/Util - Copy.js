var ResultData;
var txt='';
var script='<script>';
var Role='Admin';


var  config = {
         // data: test_data,
			xkey: 'y',
			ykeys: ['a', 'b'],
            labels: ['Total Income', 'Total Outcome'],
            fillOpacity: 0.6,
            hideHover: 'auto',
            behaveLikeLine: true,
            resize: true,
            pointFillColors:['#ffffff'],
            pointStrokeColors: ['black'],
            lineColors:['red','green']
		
        };





$(document).ready(function(){
	var paramtest='ClassName=';

	xml = $($.parseXML($('#XMLData').text()));
	 $(xml).find('widget').each(function(index,value){


	 if ($(this).find('Role').text()==Role)
		 {
		 if(paramtest!='ClassName=')
			 paramtest=paramtest+",";
		 	 paramtest=paramtest+$(this).find('Title').text();
		 
			 
		 }
	 });
	var jsonData ;
	$.ajax({  
	    type: "GET",  
	    url: "http://10.219.161.21:8080/JerseyRestWebService/rest/service/dynamicjson1", 
	    data: paramtest,
	    dataType: "json", 
	    success: function(json){  
	    	//config.data =  json.data
	    	console.log(JSON.stringify(json.data));
	    	var paramtest='ClassName=';

	    	xml = $($.parseXML($('#XMLData').text()));
	    	 $(xml).find('widget').each(function(index,value){


	    	 if ($(this).find('Role').text()==Role)
	    		 {
	    		 config.data = json.data;
	    		 // alert(JSON.stringify(config.data));
	    		 
	    		 var Title="<h1>"+$(this).find('Title').text()+"</h1>"
	    		 // // alert(Title);
	    		 var ChartType= "<div id=\""+$(this).find('Title').text()+"\"><\/div>";
	    		 // // alert(ChartType);
	    		 txt=txt+Title+ChartType;
	    		 // // alert(txt);
	    		 script=script+"config.element=\'"+$(this).find('Title').text()+"\';";
	    		
	    		 if($(this).find('ChartType').text()=="AreaChart")
	    			 script=script+"Morris.Area(config);"; 
	    		 else if($(this).find('ChartType').text()=="BarChart")
	    			 script=script+"Morris.Bar(config);"; 
	    		 else
	    			 script=script+"Morris.Line(config);";  
	    		 }
	    	
	    	  });
	    	script=script+"</script>"
	    	// alert(script);
//	    	 $(document.body).append(txt);
//	    	 $(document.body).append(script);
	    	 
	    	 $('#AreaChart').append(txt);
	    	 $('#AreaChart').append(script);
	    	 
	      },  
	      error: function(e){  
	        // alert('ERRORRRRRRR: ' + e);  
	      } 
	  });
		
});

