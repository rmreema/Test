package com.widget;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.google.gson.Gson;
import com.test.Database;

public class WidgetReader {
	

	public String getWidgetList( String role) {
		Connection conn= Database.getDBConnection();
		Statement stmt;
		ResultSet rs;
		String jsonStr = null;
		ArrayList<Widget> widgetList = new ArrayList<>();

		try {
			 stmt = conn.createStatement();
			 String sql = "SELECT * FROM Widget where role='"+role+"'";
		     rs= stmt.executeQuery(sql);
		     while(rs.next()){
		    	 Widget widget= new Widget();
		    	 widget.setChartType(rs.getString(1));
		    	 widget.setXkey(rs.getString(2));
		    	 widget.setYkeys(rs.getString(3));
		    	 widget.setTitle(rs.getString(4));
		    	 widget.setRole(rs.getString(5));
		    	 widgetList.add(widget);
		     }
			
		 Gson gson = new Gson();
		 jsonStr = gson.toJson(widgetList);
		} catch(SQLException e) {
			e.printStackTrace();
		}
		return jsonStr;
	}
}