package com.test;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class TestLogin {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		System.out.println("TestLogin");
		
		
		//String filePath = new File(System.getProperty("catalina.base"))+ "/webapps/strsproperties/strs.properties";
		
		Connection connection = null;
		try {
			Class.forName("org.h2.Driver");
		
		connection = DriverManager.getConnection("jdbc:h2:~/MyDB", "root", "root");		
		System.out.println("Connection:::"+connection);
		Statement stmt = connection.createStatement();
		//create table usersTables(user_name varchar(15) not null primary key, user_pass varchar(15) not null)
		//int status = stmt.executeUpdate("insert into usersTables values('test','testpass')");
		//stmt.execute("create table user_roles (user_name varchar(15) not null, role_name varchar(15) not null, primary key (user_name, role_name))");
		//int status = stmt.executeUpdate("insert into usersTables values('chandra','chandra')");
		String qury = "ALTER TABLE Widget ADD Role varchar(10)";
		//String qry = "create table Widget(chartType varchar(15) , xkeys varchar(15) , ykeys varchar(15), title varchar(15))";
		stmt.execute(qury);
		ResultSet rs = stmt.executeQuery("select * from Widget");
		ResultSetMetaData rsmd = rs.getMetaData();
	    int numCols = rsmd.getColumnCount();
		System.out.println("numCols::::"+numCols);
		 for (int i = 1; i <= numCols; i++) {
		      if (i > 1)
		        System.out.print(", ");
		      System.out.print(rsmd.getColumnLabel(i));
		    }
		/*while(rs.next()){
			System.out.println(rs.getString("user_name")+"===="+rs.getString("user_pass"));
		}
		
		ResultSet rs1 = stmt.executeQuery("select * from user_roles");
		while(rs1.next()){
			System.out.println(rs1.getString("user_name")+"====>>>"+rs1.getString("role_name"));
		}*/
		
		
		//System.out.println(status);
		
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			connection.close();
		}
	}

}
