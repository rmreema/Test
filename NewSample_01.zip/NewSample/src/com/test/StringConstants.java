package com.test;

/**
 * @author 582066
 *
 */
public class StringConstants {

	public static final String DB_DRIVER = "org.h2.Driver";
	public static final String DB_CONNECTION = "jdbc:h2:~/MyDB";
	public static final String DB_USER = "root";
	public static final String DB_PASSWORD = "root";
	public static final int REST_DAO = 1;

	public static final String PACKAGE_NAME = "com.monsanto.model";
	public static final String PSQL_FACTORY_NAME ="PSql";
	public static final String ROLE_NAME ="one";

}
