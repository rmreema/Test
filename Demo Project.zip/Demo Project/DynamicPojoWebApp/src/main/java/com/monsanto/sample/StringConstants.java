package com.monsanto.sample;

public final class StringConstants {

	private static final String DB_DRIVER = "org.h2.Driver";
	private static final String DB_CONNECTION = "jdbc:h2:D:/dynamicobject";
	private static final String DB_USER = "root";
	private static final String DB_PASSWORD = "root";
	
	
}
