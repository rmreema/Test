package com.monsanto.sample;

import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;

public class RestDAO {

	private static final String DB_DRIVER = "org.h2.Driver";
	private static final String DB_CONNECTION = "jdbc:h2:D:/dynamicobject";
	private static final String DB_USER = "root";
	private static final String DB_PASSWORD = "root";

	public List<Object> loadDynamicObjectFromDB(String className, String tableColumns, String filterBy) {

		List<Object> dynamicObjects = new ArrayList<>();

		Connection connection = getDBConnection();
		Statement stmt = null;
		try {
			connection.setAutoCommit(false);
			stmt = connection.createStatement();

			Object classObject = Class.forName(className).newInstance();
			Class c = classObject.getClass();
			if("".equalsIgnoreCase(tableColumns)){
				tableColumns = "*";
			}
			String query = "SELECT " + tableColumns + " FROM " + c.getSimpleName() + " " + filterBy;

			PreparedStatement preparedStmt = connection.prepareStatement(query);

			ResultSet rs = preparedStmt.executeQuery();

			while (rs.next()) {
				Object object = Class.forName(className).newInstance();

				Field[] allFields = object.getClass().getDeclaredFields();

				for (Field field : allFields) {
					if (checkTableColumnExitOrNotInResultSet(rs.getMetaData(), field.getName())) {
						BeanUtils.setProperty(object, field.getName(), rs.getString(field.getName()));
						System.out.println("Column Name ::" + field.getName() + " Column Value :: "
								+ rs.getString(field.getName()));
					}
				}

				dynamicObjects.add(object);
			}

			stmt.close();
			connection.commit();

			stmt.close();
			connection.commit();
		} catch (SQLException e) {
			System.out.println("Exception Message " + e.getLocalizedMessage());
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return dynamicObjects;

	}

	private boolean checkTableColumnExitOrNotInResultSet(ResultSetMetaData metaData, String columnName) {
		int numCol;
		try {
			numCol = metaData.getColumnCount();
			for (int i = 1; i < numCol + 1; i++) {
				if (metaData.getColumnName(i).equalsIgnoreCase(columnName)) {
					return true;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return false;

	}

	public static void main(String[] args) {
		Object object;
		try {
			object = Class.forName("com.monsanto.sample.Pojo3").newInstance();
			Class c = object.getClass();
			System.out.println("Package: " + c.getPackage() + "\nClass: " + c.getSimpleName() + "\nFull Identifier: "
					+ c.getName());
		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private static Connection getDBConnection() {
		Connection dbConnection = null;
		try {
			Class.forName(DB_DRIVER);
		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
		try {
			dbConnection = DriverManager.getConnection(DB_CONNECTION, DB_USER, DB_PASSWORD);
			return dbConnection;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return dbConnection;
	}
}
