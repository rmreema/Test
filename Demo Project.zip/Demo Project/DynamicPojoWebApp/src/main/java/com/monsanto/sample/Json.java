package com.monsanto.sample;

import java.util.ArrayList;
import java.util.List;

public class Json {
	private String element;
	private List<Object> data = new ArrayList<>();
	private String xkey;
	private String ykeys;
	private String labels;

	/**
	 * @return the element
	 */
	public String getElement() {
		return element;
	}

	/**
	 * @param element
	 *            the element to set
	 */
	public void setElement(String element) {
		this.element = element;
	}

	/**
	 * @return the data
	 */
	public List<Object> getData() {
		return data;
	}

	/**
	 * @return the xkey
	 */
	public String getXkey() {
		return xkey;
	}

	/**
	 * @param xkey
	 *            the xkey to set
	 */
	public void setXkey(String xkey) {
		this.xkey = xkey;
	}

	/**
	 * @return the ykeys
	 */
	public String getYkeys() {
		return ykeys;
	}

	/**
	 * @param ykeys
	 *            the ykeys to set
	 */
	public void setYkeys(String ykeys) {
		this.ykeys = ykeys;
	}

	/**
	 * @return the labels
	 */
	public String getLabels() {
		return labels;
	}

	/**
	 * @param labels
	 *            the labels to set
	 */
	public void setLabels(String labels) {
		this.labels = labels;
	}

	/**
	 * @param data
	 *            the data to set
	 */
	public void setData(List<Object> data) {
		this.data = data;
	}

	public Json() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param element
	 * @param data
	 * @param xkey
	 * @param ykeys
	 * @param labels
	 */
	public Json(String element, List<Object> data, String xkey, String ykeys, String labels) {
		super();
		this.element = element;
		this.data = data;
		this.xkey = xkey;
		this.ykeys = ykeys;
		this.labels = labels;
	}

	/**
	 * @param element
	 * @param data
	 */
	public Json(String element, List<Object> data) {
		super();
		this.element = element;
		this.data = data;
	}

}
