package com.monsanto.sample;

import java.util.ArrayList;
import java.util.List;

public class Pojo1 {
	private String id1;
	private String name1;

	private List<Object> data = new ArrayList<>();
	
	
	
	/**
	 * @return the id1
	 */
	public String getId1() {
		return id1;
	}

	/**
	 * @param id1
	 *            the id1 to set
	 */
	public void setId1(String id1) {
		this.id1 = id1;
	}

	/**
	 * @return the name1
	 */
	public String getName1() {
		return name1;
	}

	/**
	 * @param name1
	 *            the name1 to set
	 */
	public void setName1(String name1) {
		this.name1 = name1;
	}

	public Pojo1() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param id1
	 * @param name1
	 */
	public Pojo1(String id1, String name1) {
		super();
		this.id1 = id1;
		this.name1 = name1;
	}

	public String test1(String name) {
		System.out.println("Name is :: " + name);
		return name;
	}

	/**
	 * @return the data
	 */
	public List<Object> getData() {
		return data;
	}

	/**
	 * @param data the data to set
	 */
	public void setData(List<Object> data) {
		this.data = data;
	}

}
