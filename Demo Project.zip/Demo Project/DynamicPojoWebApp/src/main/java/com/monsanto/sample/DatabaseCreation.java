package com.monsanto.sample;

import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;

public class DatabaseCreation {

	private static final String DB_DRIVER = "org.h2.Driver";
	private static final String DB_CONNECTION = "jdbc:h2:D:/dynamicobject";
	private static final String DB_USER = "root";
	private static final String DB_PASSWORD = "root";

	public static void main(String[] args) throws SQLException {
		Connection connection = getDBConnection();
		Statement stmt = null;
		try {
			connection.setAutoCommit(false);
			stmt = connection.createStatement();

			// String jsonStructure = JsonTestClass.convertJsonStructure();

			/*stmt.execute(
					"CREATE TABLE Pojo3(id varchar(100) primary key,name varchar(100), desc varchar(100), location varchar(100), address varchar(100))");*/

			/*stmt.execute(
					"INSERT INTO Pojo3(id ,name , desc , location , address ) VALUES('582066', 'Arun','Associate','CKC','Madurai')");
			stmt.execute(
					"INSERT INTO Pojo3(id ,name , desc , location , address ) VALUES('121212', 'arun1','Associate','CKC','chennai')");*/

		
			//ResultSet rs = stmt.executeQuery("select * from Pojo3");

			String query = "SELECT name FROM "+"POJO3"+" WHERE id=?";

			PreparedStatement preparedStmt = connection.prepareStatement(query);
			preparedStmt.setString(1, "582066");
			ResultSet rs = preparedStmt.executeQuery();
			
			ResultSetMetaData metaData = rs.getMetaData();
			
			List<Object> dynamicObjects = new ArrayList<>();
		
			while (rs.next()) {
				Object object = Class.forName("com.monsanto.sample.Pojo3").newInstance();

				Field[] allFields = object.getClass().getDeclaredFields();

				for (Field field : allFields) {
					if (checkTableColumnExitOrNotInResultSet(metaData, field.getName())) {
						BeanUtils.setProperty(object, field.getName(), rs.getString(field.getName()));
						System.out.println("Column Name ::" + field.getName() + " Column Value :: "
								+ rs.getString(field.getName()));
					}
				}

				dynamicObjects.add(object);

			}

			stmt.close();
			connection.commit();
		} catch (SQLException e) {
			System.out.println("Exception Message " + e.getLocalizedMessage());
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			connection.close();
		}
	}

	
	private static boolean checkTableColumnExitOrNotInResultSet(ResultSetMetaData metaData, String columnName) {
		int numCol;
		try {
			numCol = metaData.getColumnCount();
			for (int i = 1; i < numCol + 1; i++) {
				if (metaData.getColumnName(i).equals(columnName)) {
					return true;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return false;

	}
	private static Connection getDBConnection() {
		Connection dbConnection = null;
		try {
			Class.forName(DB_DRIVER);
		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
		try {
			dbConnection = DriverManager.getConnection(DB_CONNECTION, DB_USER, DB_PASSWORD);
			return dbConnection;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return dbConnection;
	}

}
