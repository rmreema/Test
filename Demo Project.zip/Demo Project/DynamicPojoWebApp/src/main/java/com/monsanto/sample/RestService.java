package com.monsanto.sample;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Path("/RestService")
public class RestService {

	RestDAO restDAO = new RestDAO();

	@GET
	@Path("/dynamicobject")
	@Produces(MediaType.APPLICATION_XML)
	// @Produces(MediaType.APPLICATION_JSON)
	public List<User> getUsers() {
		Object whatInstance;
		try {
			whatInstance = Class.forName("com.monsanto.sample.User").newInstance();
			List<User> objects = new ArrayList<User>();

			User user = (User) whatInstance;
			objects.add(user);

			System.out.println(whatInstance.toString());
			return objects;

		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;

	}

	@GET
	@Path("/jsondatas")
	@Produces(MediaType.APPLICATION_JSON)
	public String loadJsonDatas(@QueryParam("param") String param) {

		try {
			ObjectMapper mapper = new ObjectMapper();

			Object whatInstance = Class.forName(param).newInstance();

			String jsonInString = "";
			try {
				jsonInString = mapper.writeValueAsString(whatInstance);
				System.out.println(jsonInString);

			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			return jsonInString;

		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;

	}

	@GET
	@Path("/loaddbdata")
	@Produces(MediaType.APPLICATION_JSON)
	public String loadJsonDBDatas(@QueryParam("ClassName") String className, @QueryParam("Columns") String columns,
			@QueryParam("FilterBy") String filterBy) {

		try {

			ObjectMapper mapper = new ObjectMapper();

			List<Object> dynamicDbObject = restDAO.loadDynamicObjectFromDB(className, checkNULL(columns),
					checkNULL(filterBy));

			Json json = new Json("JsonData", dynamicDbObject);

			String jsonInString = "";
			try {
				jsonInString = mapper.writeValueAsString(json);
				System.out.println(jsonInString);

			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			return jsonInString;

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;

	}

	private String checkNULL(String params) {
		if (params == null) {
			params = "";
		}
		return params;
	}

	@GET
	@Path("/json1")
	@Produces(MediaType.APPLICATION_JSON)
	public String json1() {
		Object whatInstance;
		try {
			whatInstance = Class.forName("com.monsanto.sample.Pojo1").newInstance();

			ObjectMapper mapper = new ObjectMapper();
			Pojo1 pojo1 = (Pojo1) whatInstance;
			pojo1.setId1("582066");
			pojo1.setName1("Arun");

			List<Object> objects = new ArrayList<>();
			Pojo2 pojo2 = new Pojo2("a", "a1");
			Pojo2 pojo21 = new Pojo2("a", "a1");
			Pojo2 pojo22 = new Pojo2("a", "a1");
			Pojo2 pojo23 = new Pojo2("a", "a1");

			objects.add(pojo2);
			objects.add(pojo21);
			objects.add(pojo22);
			objects.add(pojo23);

			pojo1.setData(objects);

			String jsonInString = "";
			try {
				jsonInString = mapper.writeValueAsString(pojo1);
				System.out.println(jsonInString);

			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			return jsonInString;

		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;

	}

	@GET
	@Path("/json")
	@Produces(MediaType.APPLICATION_JSON)
	public String json() {
		try {

			ObjectMapper mapper = new ObjectMapper();

			String element = "Test";
			List<Object> datas = new ArrayList<>();

			Pojo2 pojo2 = new Pojo2("1", "a");
			Pojo2 pojo21 = new Pojo2("1", "a");
			Pojo2 pojo22 = new Pojo2("1", "a");

			datas.add(pojo2);
			datas.add(pojo21);
			datas.add(pojo22);

			Json json = new Json(element, datas);

			String jsonInString = "";
			try {
				jsonInString = mapper.writeValueAsString(json);
				System.out.println(jsonInString);

			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			return jsonInString;

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;

	}

	@GET
	@Path("/test")
	@Produces(MediaType.APPLICATION_JSON)
	public String test() {
		Object whatInstance;
		try {
			whatInstance = Class.forName("com.monsanto.sample.Pojo1").newInstance();
			Pojo1 pojo1 = (Pojo1) whatInstance;
			pojo1.setId1("582066");
			pojo1.setName1("Arun");

			return pojo1.toString();

		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;

	}

}
