
$(document).ready(function(){
	
	var paramtest='';
	
	xml = $($.parseXML($('#XMLData').text()));
	 $(xml).find('widget').each(function(index,value){
	 paramtest =paramtest+ $(this).find('Title').text();
		alert(paramtest);  		  
	console.log($(this).find('Title').text());
	console.log($(this).find('ChartType').text());
	console.log($(this).find('xkey').text());
	console.log($(this).find('ykeys').text());
	console.log($(this).find('labels').text());
	
	  });
	
	  $.ajax({  
	      type: "GET",  
	      url: "http://10.219.161.21:8080/JerseyRestWebService/rest/service/dynamicjson?ClassName=SampleModel,Pojo3",  
	      dataType: "json", 
	      success: function(json){  
	          // we have the response  
	                  debugger;
	      		console.log(JSON.stringify(json));
	      	 /*    $.each(json.data,function(ind, datum){
	      	       //   console.log("x: " + datum.x + " y: " + datum.y + " z: " + datum.z);
	      	    //	$("#nav").html('<p>' + datum.x + " " + datum.y + " " + datum.z + '</p>');
	      	    	$(".nav").html(datum.x + " " + datum.y + " " + datum.z);
	      	    }) */
	        },  
	        error: function(e){  
	          alert('ERRORRRRRRR: ' + e);  
	        } 
	    });
		
});


var test_data = [
    {x: '2010 Q4', y: 3, z: 7},
    {x: '2011 Q1', y: 3, z: 4},
    {x: '2011 Q2', y: null, z: 1},
    {x: '2011 Q3', y: 2, z: 5},
    {x: '2011 Q4', y: 8, z: 2},
    {x: '2012 Q1', y: 4, z: 4}
  ],
  test_data2 = [
    {x: '2012 Q2', y: 3, z: 7},
    {x: '2012 Q3', y: 3, z: 4},
    {x: '2012 Q4', y: null, z: 1},
    {x: '2013 Q1', y: 2, z: 5},
    {x: '2013 Q2', y: 8, z: 2},
    {x: '2013 Q3', y: 4, z: 4}
  ],
  config = {
      data: test_data,
      xkey: 'x',
      ykeys: ['y', 'z'],
      labels: ['Total Income', 'Total Outcome'],
      fillOpacity: 0.6,
      hideHover: 'auto',
      behaveLikeLine: true,
      resize: true,
      pointFillColors:['#ffffff'],
      pointStrokeColors: ['black'],
      lineColors:['gray','red']
  }; 
