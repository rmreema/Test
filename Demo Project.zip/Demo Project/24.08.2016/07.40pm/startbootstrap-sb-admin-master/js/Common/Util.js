var ResultData;
var test_data = [
                 {x: '2010 Q4', y: 3, z: 7},
                 {x: '2011 Q1', y: 3, z: 4},
                 {x: '2011 Q2', y: null, z: 1},
                 {x: '2011 Q3', y: 2, z: 5},
                 {x: '2011 Q4', y: 8, z: 2},
                 {x: '2012 Q1', y: 4, z: 4}
               ],
      config = {
      fillOpacity: 0.6,
      hideHover: 'auto',
      behaveLikeLine: true,
      resize: true,
      pointFillColors:['#ffffff'],
      pointStrokeColors: ['black'],
      lineColors:['gray','red']
  }; 



var x2js = new X2JS();

function convertXml2JSon() {
    $("#jsonArea").val(JSON.stringify(x2js.xml_str2json($("#xmlArea").val())));
}


$(document).ready(function(){
	
	var paramtest='ClassName=';
	
	
	xml = $($.parseXML($('#XMLData').text()));
	 $(xml).find('widget').each(function(index,value){
	
		 if (paramtest!='ClassName=') paramtest =paramtest+',';
	 paramtest =paramtest+ $(this).find('Title').text();

	  });
	
	  $.ajax({  
	      type: "GET",  
	      url: "http://10.219.161.21:8080/JerseyRestWebService/rest/service/dynamicjson",  
	      data: paramtest,
	      dataType: "json", 
	      success: function(json){  
	    	 // ResultData=JSON.stringify(json);
	    	  ResultData=JSON.stringify(json);
			  alert(ResultData);
	        },  
	        error: function(e){  
	          alert('ERRORRRRRRR: ' + e);  
	        } 
	    });

	 // $('#morris-area-chart').html("");
/*	  xml = $($.parseXML($('#XMLData').text()));
		 $(xml).find('widget').each(function(index,value){
		  // alert(ResultData[0].data);
		    config.element='morris-area-chart';
		  config.data=test_data;
		  //config.data=ResultData[index].data;
		   config.xkey='x';//$(this).find('xkey').text();	 
		   config.ykeys='y,z'//$(this).find('ykeys').text();
		   config.labels='y,z'//$(this).find('labels').text();
			
				 Morris.Area(config);
});*/
	  
		
});

