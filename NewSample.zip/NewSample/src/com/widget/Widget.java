package com.widget;

public class Widget {
	private String Title;
	private String ChartType;
	private String xkey;
	private String ykeys;
	private String labels;
	private String Role;

	public String getTitle() {
		return Title;
	}

	public void setTitle(String title) {
		this.Title = title;
	}

	public String getChartType() {
		return ChartType;
	}

	public void setChartType(String chartType) {
		this.ChartType = chartType;
	}

	public String getXkey() {
		return xkey;
	}

	public void setXkey(String xkey) {
		this.xkey = xkey;
	}

	public String getYkeys() {
		return ykeys;
	}

	public void setYkeys(String ykeys) {
		this.ykeys = ykeys;
	}

	public String getLabels() {
		return labels;
	}

	public void setLabels(String labels) {
		this.labels = labels;
	}

	public String getRole() {
		return Role;
	}

	public void setRole(String Role) {
		this.Role = Role;
	}

	@Override
	public String toString() {
		return "Widget [title=" + Title + ", chartType=" + ChartType + ", xkey=" + xkey + ", ykeys=" + ykeys
				+ ", labels=" + labels + ", Role=" + Role + "]";
	}

}
/*
 * <widgets> //Create two widgets <widget> <Title>SampleModel</Title>
 * <ChartType>area-chart</ChartType> <xkey>x</xkey> <ykeys>y,z</ykeys>
 * <labels>y,z</labels> <Role>Admin</Role> </widget>
 * 
 * <widget> <Title>SampleModel</Title> <ChartType>area-chart</ChartType>
 * <xkey>x</xkey> <ykeys>y,z</ykeys> <labels>y,z</labels> <Role>Finance</Role>
 * 
 * </widget>
 * 
 * </widgets>
 */