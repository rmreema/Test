package com.monsanto.model;

import javassist.ClassPool;
import javassist.CtClass;

public class MyClassLoader extends ClassLoader {

	final static String basePath = "/D:/Software/apache-tomcat-8.5.4/webapps/monsanto/WEB-INF/classes/";

    @Override
    protected Class<?> findClass(final String name) throws ClassNotFoundException {
        String fullName = name.replace('.', '/');
        fullName += ".class";

        String path = basePath + fullName ;
        try {
            
        	ClassPool p = ClassPool.getDefault();
			p.insertClassPath(basePath);
			CtClass cc = p.get("com.monsanto.model.DefectTrack");
			 byte[] data = cc.toBytecode();
            
            Class<?> res = defineClass(name, data, 0, data.length);

            return res;
        } catch(Exception e) {
            return super.findClass(name);
        }
    }
}
