package com.test;

import com.monsanto.model.UserDetails;
import com.opensymphony.xwork2.ActionSupport;

public class HelloAction extends ActionSupport {
	/**
	* 
	*/
	public HelloAction() {
		System.out.println("Hhelloo Action=======asdfasdfasdfsdf==");
	}

	private static final long serialVersionUID = 1L;
	private String name;
	private String password;
	private String role;
	

	/**
	 * @return the role
	 */
	public String getRole() {
		return role;
	}

	/**
	 * @param role the role to set
	 */
	public void setRole(String role) {
		this.role = role;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String execute() throws Exception {
		String pageName = "dashboard";
		DAOService service = new DAOService();
		UserDetails userDetails = service.validateCredentials(name, password);

		if (userDetails.getName() != null && userDetails.getName().equals(name)
				&& userDetails.getPassword() != null && userDetails.getPassword().equals(password)) {

			if (StringConstants.ROLE_NAME.equalsIgnoreCase(userDetails.getRole())) {
				pageName = "success";
			} else {
				role = userDetails.getRole();
				pageName = "dashboard";
			}

		} else {
			pageName = "error";
		}
		return pageName;
	}
}