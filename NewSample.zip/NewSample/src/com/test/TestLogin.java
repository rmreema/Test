package com.test;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class TestLogin {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		System.out.println("TestLogin");
		
		
		//String filePath = new File(System.getProperty("catalina.base"))+ "/webapps/strsproperties/strs.properties";
		String filePath1 = new File(System.getProperty("catalina.base"))+ "/webapps";
		System.out.println("Bosssssssssssssss=====>"+filePath1); 

		Connection connection = null;
		try {
			Class.forName("org.h2.Driver");
		
		connection = DriverManager.getConnection("jdbc:h2:~/H2Database", "testUser", "test");		
		System.out.println("Connection:::"+connection);
		Statement stmt = connection.createStatement();
		//create table usersTables(user_name varchar(15) not null primary key, user_pass varchar(15) not null)
		//int status = stmt.executeUpdate("insert into usersTables values('test','testpass')");
		//stmt.execute("create table user_roles (user_name varchar(15) not null, role_name varchar(15) not null, primary key (user_name, role_name))");
		//int status = stmt.executeUpdate("insert into usersTables values('chandra','chandra')");
		ResultSet rs = stmt.executeQuery("select * from usersTables");
		while(rs.next()){
			System.out.println(rs.getString("user_name")+"===="+rs.getString("user_pass"));
		}
		
		ResultSet rs1 = stmt.executeQuery("select * from user_roles");
		while(rs1.next()){
			System.out.println(rs1.getString("user_name")+"====>>>"+rs1.getString("role_name"));
		}
		
		
		//System.out.println(status);
		
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			connection.close();
		}
	}

}
