package com.test;

import java.io.BufferedInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.Principal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;

import javassist.CannotCompileException;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtField;
import javassist.CtMethod;
import javassist.bytecode.AccessFlag;
import javassist.bytecode.ClassFile;

public class UploadAction extends ActionSupport {

	private static final long serialVersionUID = 1L;

	private File uploadFile;
	private String uploadFileContentType;
	private String uploadFileFileName;
	private String userName;
	private String roleName;
	private String DB_DRIVER = "org.h2.Driver";
	private String DB_CONNECTION = "jdbc:h2:D:/dynamicobject";
	private String DB_USER = "root";
	private String DB_PASSWORD = "root";

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public File getUploadFile() {
		return uploadFile;
	}

	public void setUploadFile(File uploadFile) {
		this.uploadFile = uploadFile;
	}

	public String getUploadFileContentType() {
		return uploadFileContentType;
	}

	public void setUploadFileContentType(String uploadFileContentType) {
		this.uploadFileContentType = uploadFileContentType;
	}

	public String getUploadFileFileName() {
		return uploadFileFileName;
	}

	public void setUploadFileFileName(String uploadFileFileName) {
		this.uploadFileFileName = uploadFileFileName;
	}

	public String execute() {

		HSSFCell column1 = null;
		HSSFCell column2 = null;
		HSSFCell column3 = null;
		HSSFCell column4 = null;
		String cell1 = null;
		String cell2 = null;
		String cell3 = null;
		String cell4 = null;
		String sheetName = null;
		List<DataInsert> list = new ArrayList<DataInsert>();
		try {

			File fileupload = getUploadFile();
			DataInsert dataInsert = null;
			try {
				InputStream input = new BufferedInputStream(new FileInputStream(fileupload));
				POIFSFileSystem fs = new POIFSFileSystem(input);
				HSSFWorkbook wb = new HSSFWorkbook(fs);
				HSSFSheet sheet = wb.getSheetAt(0);
				sheetName = wb.getSheetName(0);
				getDynamicPoJo(sheetName, sheet);
				getExcelDynamicData(sheetName, sheet);
				Iterator rows = sheet.rowIterator();

				while (rows.hasNext()) {

					HSSFRow row = (HSSFRow) rows.next();
					column1 = row.getCell(0);
					column2 = row.getCell(1);
					column3 = row.getCell(2);

					System.out.println("\n");
					Iterator cells = row.cellIterator();
					dataInsert = new DataInsert();
					while (cells.hasNext()) {
						HSSFCell cell = (HSSFCell) cells.next();
							
						 if (0 == cell.getColumnIndex()) {						
								dataInsert.setY(getvalue(cell));
								cell1 = getvalue(cell);							
						} else if (1 == cell.getColumnIndex()) {		
								dataInsert.setA(getvalue(cell));
								cell2 = getvalue(cell);				
						} else if (2 == cell.getColumnIndex()) {							
								dataInsert.setB(getvalue(cell));
								cell3 = getvalue(cell);								
							}
						
						
						if (getvalue(cell) != null) {
							dataInsert.setY(cell1);
						}
						if (getvalue(cell) != null) {
							dataInsert.setA(cell2);
						}
						if (getvalue(cell) != null) {
							dataInsert.setB(cell3);
						}

					}

					if(row.getRowNum()>0){
						insertRowInDB(dataInsert,sheetName);
					}

				}
			} catch (Exception e) {
				e.printStackTrace();
			}

			
			//getUserDetails();
		} catch (Exception e) {
			e.printStackTrace();
			addActionError(e.getMessage());
			return INPUT;

		}
		return SUCCESS;
	}

	public String getvalue(HSSFCell cell){
		String value=null;
		if (HSSFCell.CELL_TYPE_STRING == cell.getCellType() ){
			value = cell.getStringCellValue();
		}else if(HSSFCell.CELL_TYPE_NUMERIC == cell.getCellType()){
			 value = String.valueOf(cell.getNumericCellValue());			
		}else if(HSSFCell.CELL_TYPE_BOOLEAN == cell.getCellType()){
			 value= String.valueOf(cell.getBooleanCellValue());
		}
		return value;
		
	}

	public void getExcelDynamicData(String sheetName, HSSFSheet sheetRows) {
		StringBuffer sb = new StringBuffer();
		StringBuffer sb3 = new StringBuffer();
		StringBuffer sb2 = sb.append("CREATE TABLE " + sheetName + " (");
		Iterator rows = sheetRows.rowIterator();
		int noRows = sheetRows.getPhysicalNumberOfRows();

		for (int i = 0; i < noRows; i++) {
			HSSFRow row1 = sheetRows.getRow(i);
			int cells = row1.getPhysicalNumberOfCells();
			System.out.println("No of cells in Excel data" + cells);
			if (0 == row1.getRowNum()) {
				for (int j = 0; j < cells; j++) {
					HSSFCell cellval = row1.getCell(j);
					System.out.println("Row Cell val ------->" + row1.getCell(i).toString());

					sb3 = sb2.append(cellval.getStringCellValue()).append(" ").append("VARCHAR(255),");
				}
				sb3.append(");");

			}
		}

		sb3.deleteCharAt(sb3.toString().length() - 3);
		System.out.println("StringBufferVal  lastChar last one ----->" + sb3.toString());
		
		
		Connection connection = getDBConnection();
		Statement stmt = null;
		try {
			connection.setAutoCommit(false);
			stmt = connection.createStatement();
			stmt.execute(sb3.toString());
			stmt.close();
			connection.commit();
		} catch (SQLException e) {
			System.out.println("Exception Message " + e.getLocalizedMessage());
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public void getDynamicPoJo(String sheetName, HSSFSheet sheetRows) {

		int noRows = sheetRows.getPhysicalNumberOfRows();
		ClassPool pool = ClassPool.getDefault();
		CtClass cc = pool.makeClass("com.monsanto.model." + sheetName.toString());
		HSSFRow row1 = null;
		for (int i = 0; i < noRows; i++) {
			row1 = sheetRows.getRow(i);
			int cells = row1.getPhysicalNumberOfCells();
			System.out.println("No of cells in Excel data" + cells);

			for (int j = 0; j < cells; j++) {

				if (row1.getRowNum() == 0) {
					HSSFCell cellval = row1.getCell(j);

					CtClass column1cls;
					try {
						column1cls = ClassPool.getDefault().get("java.lang.String");
						CtField fcolumn1;
						fcolumn1 = new CtField(column1cls, row1.getCell(j).toString(), cc);
						fcolumn1.setModifiers(AccessFlag.PUBLIC);
						cc.addField(fcolumn1);
						cc.addMethod(generateGetter(cc, row1.getCell(j).toString(), java.lang.String.class));
						cc.addMethod(generateSetter(cc, row1.getCell(j).toString(), java.lang.String.class));

					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

			}

		}
		if (noRows >= 0) {
			File fpath = new File(
					"D:\\Software\\apache-tomcat-8.5.4\\webapps\\monsanto\\WEB-INF\\classes\\com\\monsanto\\model\\" + sheetName + ".class");

			ClassFile ccFile = cc.getClassFile();
			try {
				ccFile.write(new DataOutputStream(new FileOutputStream(fpath)));
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

	}

	private static CtMethod generateGetter(CtClass declaringClass, String fieldName, Class fieldClass)
			throws CannotCompileException {

		String getterName = "get" + fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1);
		System.out.println("GetterName---" + getterName);
		StringBuffer sb = new StringBuffer();
		sb.append("public ").append(fieldClass.getName()).append(" ").append(getterName).append("() { ")
				.append("return  " + fieldName + ";").append("}");
		return CtMethod.make(sb.toString(), declaringClass);

	}

	private static CtMethod generateSetter(CtClass declaringClass, String fieldName, Class fieldClass)
			throws CannotCompileException {

		String setterName = "set" + fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1);
		System.out.println("setterName------" + setterName);
		StringBuffer sb = new StringBuffer();
		sb.append("public void ").append(setterName).append("").append("(").append(fieldClass.getName()).append(" ")
				.append(fieldName).append(")").append("{ ").append("this.").append(fieldName).append("=")
				.append(fieldName).append(";").append("}");
		System.out.println("SB TO String " + sb.toString());
		return CtMethod.make(sb.toString(), declaringClass);

	}

/*	private void getUserDetails() {

		System.out.println("Getting User Detailsss...");
		String userRole = null;
		HttpServletRequest request = ServletActionContext.getRequest();
		Principal principal = request.getUserPrincipal();
		setUserName(principal.getName());

		if (request.isUserInRole("Admin")) {
			System.out.println("User Role : " + "Admin");
			userRole = "Admin";
		}
		if (request.isUserInRole("Customer")) {
			System.out.println("User Role : " + "Customer");
			userRole = "Customer";
		}
		if (request.isUserInRole("Financial")) {
			System.out.println("User Role : " + "Financial");
			userRole = "Financial";
		}
		setRoleName(userRole);

	}*/

	private void createTable(String sheetName, List column1s) throws SQLException {
		StringBuffer sb = new StringBuffer();
		StringBuffer sb2 = sb.append("CREATE TABLE " + sheetName + "(");
		// String sql = "CREATE TABLE "+sheetName+"("
		Iterator columnItrs = column1s.iterator();
		while (columnItrs.hasNext()) {
			String val = (String) columnItrs.next();
			System.out.println("val----->" + val);
			sb2.append(val + "varchar(255)+");
		}

		System.out.println(sb2.toString());

	}

	private Connection getDBConnection() {

		Connection dbConnection = null;
		try {
			Class.forName(DB_DRIVER);
			dbConnection = DriverManager.getConnection(DB_CONNECTION, DB_USER, DB_PASSWORD);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		return dbConnection;
	}

	public void insertRowInDB(DataInsert dataInsert, String sheetName) {
		Connection con = getDBConnection();
		try {
			PreparedStatement preparedStatement = null;
			System.out.println("dataInsert.getX()--------->" + dataInsert.getY());
			System.out.println("dataInsert.getY()--------->" + dataInsert.getA());
			System.out.println("dataInsert.getZ()--------->" + dataInsert.getB());

			String sql = "INSERT INTO "+ sheetName + "(y,a,b) VALUES (?,?,?)";
			preparedStatement = con.prepareStatement(sql);
			preparedStatement.setString(1, dataInsert.getY());// 1 specifies the
																// first
																// parameter in
																// the query

			preparedStatement.setString(2, dataInsert.getA());

			preparedStatement.setString(3, dataInsert.getB());// 1 specifies the
																// first
																// parameter in
																// the query

			int insertrows = preparedStatement.executeUpdate();
			System.out.println("insertrows---------->" + insertrows);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
