package com.test;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.SessionAware;

import com.monsanto.model.UserDetails;
import com.opensymphony.xwork2.ActionSupport;
import com.widget.WidgetReader;

public class UploadExcelAction extends ActionSupport implements SessionAware {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private File uploadFile;
	private String uploadFileContentType;
	private String uploadFileFileName;
	private String userName;
	private String roleName;
	private List<String> xCoordinateList;
	private List<String> yCoordinateList;
	private String chartType;
	private String selXCoordinate;
	private List<String> selYCoordinates;
	public String sheetName;
	HttpServletRequest request = ServletActionContext.getRequest();
    private Map<String, Object> session;
    private String key=null;
    UserDetails userDetails;
    
    public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	//HellooAction
    private String name;
	private String password;
	private String role;
	private String jsonData;
    
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getJsonData() {
		return jsonData;
	}

	public void setJsonData(String jsonData) {
		this.jsonData = jsonData;
	}
	public String showPage(){
		
		
		return SUCCESS;
	}
	public String execute() {
		key="Both";
		return SUCCESS;
	}

	public String execute1() {
		try {
			System.out.println("in Execute 1---------->");
			File fileupload = getUploadFile();
			InputStream input = new BufferedInputStream(new FileInputStream(fileupload));
			POIFSFileSystem fs = new POIFSFileSystem(input);
			HSSFWorkbook workbook = new HSSFWorkbook(fs);
			HSSFSheet sheet = workbook.getSheetAt(0);
			
			sheetName = workbook.getSheetName(0);
			request = ServletActionContext.getRequest();
			session.put("sheetName", sheetName);
			
			
			Iterator<Row> rowIterator = sheet.iterator();
			List<Map<String, String>> maps = new ArrayList<>();
			Map<Integer, String> headerMap = new HashMap<>();

			while (rowIterator.hasNext()) {
				Row row = rowIterator.next();
				// For each row, iterate through each columns
				Iterator<Cell> cellIterator = row.cellIterator();

				Map<String, String> rowMap = new HashMap<>();
				while (cellIterator.hasNext()) {

					Cell cell = cellIterator.next();

					String cellValue = "";
					switch (cell.getCellType()) {

					case Cell.CELL_TYPE_NUMERIC:
						cellValue = new BigDecimal(cell.getNumericCellValue()).toString();
						// System.out.println("Cell Value :: " + cellValue);
						break;
					case Cell.CELL_TYPE_STRING:
						cellValue = cell.getStringCellValue();
						// System.out.println("Cell Value :: " + cellValue);
						break;
					case Cell.CELL_TYPE_BOOLEAN:
						// System.out.println("boolean===>>>" +
						// cell.getBooleanCellValue() + "\t");
						break;
					}

					if (cell.getRowIndex() == 0) {
						headerMap.put(cell.getColumnIndex(), cellValue);

					} else {
						rowMap.put(headerMap.get(cell.getColumnIndex()), cellValue);
					}

				}
				
				// Skip the header row here
				if (row.getRowNum() != 0) {
					maps.add(rowMap);
				}
			}
			getCoordinates(headerMap);
			
			List<String> headers = new ArrayList<>();
			headers.addAll(headerMap.values());

			StringBuffer createTable = new StringBuffer();
			createTable.append("CREATE TABLE " + sheetName + "( ");

			StringBuffer insertScriptBuffer = new StringBuffer();
			insertScriptBuffer.append("INSERT INTO " + sheetName + "( ");

			StringBuffer appendPreparedStmt = new StringBuffer();

			Map<String, Integer> preparedStmtString = new HashMap<>();
			int i = 1;
			for (String header : headers) {

				if (headers.size() == i) {
					System.out.println("Last list value :: " + header);
					createTable.append(header + " varchar(255) )");

					appendPreparedStmt.append("? )");
					insertScriptBuffer.append(header + " ) VALUES ( " + appendPreparedStmt.toString());
				} else {
					System.out.println(header);
					createTable.append(header + " varchar(255) , ");

					insertScriptBuffer.append(header + " ,");
					appendPreparedStmt.append("?,");
				}
				preparedStmtString.put(header, i);

				i++;
			}
			System.out.println("Create Table script :: " + createTable.toString());
			System.out.println("Insert Script  :: " + insertScriptBuffer.toString());

			Connection connection = Database.getDBConnection();
			Statement stmt = null;
			try {
				connection.setAutoCommit(false);
				stmt = connection.createStatement();

				// Table has been created here
				stmt.execute(createTable.toString());

				for (Map<String, String> map : maps) {

					PreparedStatement preparedStmt = connection.prepareStatement(insertScriptBuffer.toString());

					for (Entry<String, String> obj : map.entrySet()) {
						System.out.println(preparedStmtString.get(obj.getKey()) + " - " + obj.getValue());
						preparedStmt.setString(preparedStmtString.get(obj.getKey()), obj.getValue());
					}
					preparedStmt.executeUpdate();
					preparedStmt.close();
				}

				stmt.close();
				connection.commit();

			} catch (Exception e) {
				System.out.println(e.getMessage());
			} finally {
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			input.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return INPUT;

		}
		key="upload";
		setKey(key);
		return SUCCESS;
	}
	
	public String loginAction()throws Exception{		

		String pageName = "dashboard";
		
		DAOService service = new DAOService();
		userDetails = service.validateCredentials(name, password);
		session.put("loginedUser", userDetails);

		if (userDetails.getName() != null && userDetails.getName().equals(name)
				&& userDetails.getPassword() != null && userDetails.getPassword().equals(password)) {
			
				role = userDetails.getRole();
				pageName = "dashboard";
				WidgetReader widgetReader=new WidgetReader();
				String jsonStr=widgetReader.getWidgetList(role);
				System.out.println("jsonStr==>" +jsonStr);
				setJsonData(jsonStr);
		} else {
			pageName = "error";
		}
		return pageName;
	
		
	}

	private void getCoordinates(Map<Integer, String> headerMap) {

		List<String> xCoordinateList = new ArrayList<String>();
		List<String> yCoordinateList = new ArrayList<String>();

		for (int i = 0; i < headerMap.size(); i++) {
			if (i == 0) {
				xCoordinateList.add(headerMap.get(i));
			} else {
				yCoordinateList.add(headerMap.get(i));
			}
		}
		setxCoordinateList(xCoordinateList);
		setyCoordinateList(yCoordinateList);
	}
	
	public String getWidgetDetails(){
		
		UserDetails userDetails=(UserDetails)session.get("loginedUser");
		String chartName;
		
		if(chartType.equals("1"))
			chartName="Bar";
		else if(chartType.equals("2"))
			chartName="Pie Chart";
		else 
			chartName="Line";
		
		Connection dbConnection = Database.getDBConnection();
		PreparedStatement preparedStatement = null;
		try {
			String sqlQuery= "insert into Widget(chartType,xkeys,ykeys,title,role) values(?,?,?,?,?)";
			System.out.println("Inserted widget Details: "+chartName+" "+getSelXCoordinate()+" "+getSelYCoordinates()+" "+session.get("sheetName").toString()+" "+userDetails.getRole());
			preparedStatement = dbConnection.prepareStatement(sqlQuery);
			preparedStatement.setString(1, chartName);
			preparedStatement.setString(2, getSelXCoordinate());
			preparedStatement.setString(3, getSelYCoordinates().toString());
			preparedStatement.setString(4, session.get("sheetName").toString());
			
			preparedStatement.setString(5, userDetails.getRole());
			System.out.println("sqlQuery=>"+sqlQuery);
			int status=preparedStatement.executeUpdate();
			System.out.println("insert query status is=> "+status);
			if(status==1){
				key="widget";
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return SUCCESS;
	}
	public List<String> getxCoordinateList() {
		return xCoordinateList;
	}

	public void setxCoordinateList(List<String> xCoordinateList) {
		this.xCoordinateList = xCoordinateList;
	}

	public List<String> getyCoordinateList() {
		return yCoordinateList;
	}

	public void setyCoordinateList(List<String> yCoordinateList) {
		this.yCoordinateList = yCoordinateList;
	}

	public String getChartType() {
		return chartType;
	}

	public void setChartType(String chartType) {
		this.chartType = chartType;
	}

	public String getSelXCoordinate() {
		return selXCoordinate;
	}

	public void setSelXCoordinate(String selXCoordinate) {
		this.selXCoordinate = selXCoordinate;
	}

	public List<String> getSelYCoordinates() {
		return selYCoordinates;
	}

	public void setSelYCoordinates(List<String> selYCoordinates) {
		this.selYCoordinates = selYCoordinates;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public File getUploadFile() {
		return uploadFile;
	}

	public void setUploadFile(File uploadFile) {
		this.uploadFile = uploadFile;
	}

	public String getUploadFileContentType() {
		return uploadFileContentType;
	}

	public void setUploadFileContentType(String uploadFileContentType) {
		this.uploadFileContentType = uploadFileContentType;
	}

	public String getUploadFileFileName() {
		return uploadFileFileName;
	}

	public void setUploadFileFileName(String uploadFileFileName) {
		this.uploadFileFileName = uploadFileFileName;
	}

	@Override
	public void setSession(Map<String, Object> session) {
	        this.session = session;
	}
}
