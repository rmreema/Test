package com.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.monsanto.model.UserDetails;

public class DAOService {

	public UserDetails validateCredentials(String userName, String password) {
		UserDetails userDetails = new UserDetails();
		Connection connection = getDBConnection();
		Statement stmt = null;
		try {
			connection.setAutoCommit(false);
			stmt = connection.createStatement();

			String query2 = "SELECT u.user_name,u.user_pass,r.role_name FROM  user_roles r,usersTables u WHERE u.user_name = r.user_name AND u.user_name = '"
					+ userName + "'";
			PreparedStatement preparedStmt2 = connection.prepareStatement(query2);
			ResultSet rs = preparedStmt2.executeQuery();

			while (rs.next()) {

				userDetails.setName(rs.getString("user_name"));
				userDetails.setPassword(rs.getString("user_pass"));
				userDetails.setRole(rs.getString("role_name"));
			}

			stmt.close();
			connection.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return userDetails;
	}

	/**
	 * This method mainly used for creating connection
	 * 
	 * @return
	 */
	private static Connection getDBConnection() {
		Connection dbConnection = null;
		try {
			Class.forName(StringConstants.DB_DRIVER);
		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
		try {
			dbConnection = DriverManager.getConnection(StringConstants.DB_CONNECTION, StringConstants.DB_USER,
					StringConstants.DB_PASSWORD);
			return dbConnection;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return dbConnection;
	}
}
